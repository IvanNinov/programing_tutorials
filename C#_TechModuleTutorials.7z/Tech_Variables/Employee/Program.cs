﻿using System;

namespace Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            string fName = Console.ReadLine();
            string sName = Console.ReadLine();
            string tName = Console.ReadLine();

            Console.WriteLine($"{tName}{sName}{fName}");


        }
    }
}
