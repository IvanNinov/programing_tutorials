﻿using System;

namespace Practice_Integers
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine($"Before:");
            Console.WriteLine($"a = {a}");
            Console.WriteLine($"b = {b}");

            a = a + b;
            b = a - b;
            a = a - b;



            Console.WriteLine($"After:");
            Console.WriteLine($"a = {a}");
            Console.WriteLine($"b = {b}");

            //Console.WriteLine($"{Convert.ToInt32(num1,16)}");




        }
    }
}
