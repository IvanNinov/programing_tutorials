﻿using System;
using System.Numerics;

namespace convertYears
{
    class Program
    {
        static void Main(string[] args)
        {
            int centuries = int.Parse(Console.ReadLine());
            ushort years = (ushort)(centuries * 100);
            int days = (int)(years * 365.2422);

            int hours = days * 24;

            int minutes = hours * 60;
            long seconds = minutes * 60L;
            long milisec = seconds * 1000;
            BigInteger micro = milisec * 1000;
            BigInteger nano = micro * 1000;


            Console.WriteLine($"{centuries} centuries = {years} years = {days} days = {hours} hours = {minutes} minutes = {seconds} seconds = {milisec} milliseconds = {micro} microseconds = {nano} nanoseconds");



        }
    }
}
