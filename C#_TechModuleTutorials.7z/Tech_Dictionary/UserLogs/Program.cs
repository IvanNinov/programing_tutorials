﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace UserLogs
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> IpCount = new Dictionary<string, int>();
            SortedDictionary<string, Dictionary<string, int>> userIp = new SortedDictionary<string, Dictionary<string, int>>();
            
            int count = 1;

            while (true)
            {
                string input = Console.ReadLine();
                if (input == "end")
                {
                    break;
                }
                string[] line = input.Split(' ').ToArray();
                string[] ipString = line[0].Split('=').ToArray();
                string ip = ipString[1];
                string[] userString = line[2].Split('=').ToArray();
                string user = userString[1];

                if (!userIp.ContainsKey(user))
                {
                    userIp.Add(user, new Dictionary<string, int>());
                    
                }
                if (!userIp[user].ContainsKey(ip))
                {
                    userIp[user].Add(ip, 0);
                }
                userIp[user][ip] += count;

            }

            foreach (var user in userIp)
            {
                string output = "";
                Console.WriteLine($"{user.Key}:");
                List<string> list = new List<string>();

                foreach (var item in userIp[user.Key])
                {
                    output = $"{item.Key} => {item.Value}";
                    list.Add(output);
                }

                for (int i = 0; i < list.Count; i++)
                {
                    
                    if (i == list.Count - 1)
                    {
                        Console.WriteLine(list[i] + ".");
                        break;
                    }
                    Console.Write(list[i] + ", ");
                }

            }

            

        }
    }
}
