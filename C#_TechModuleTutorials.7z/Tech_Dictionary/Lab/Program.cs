﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Lab
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] digits = { "zero", "one", "two", "three", "four", "five",
            "six", "seven", "eight", "nine" };

            var shortDogots = digits.Where((digit,index) => digit.Length < index);
            foreach (var item in shortDogots)
            {
                Console.WriteLine(item);
            }



            /*
            string[] elements = Console.ReadLine().ToLower().Split(' ');
            var countElements = new Dictionary<string, int>();

            for (int i = 0; i < elements.Length; i++)
            {
                if (!countElements.ContainsKey(elements[i]))
                {
                    countElements.Add(elements[i],1);
                }
                else
                {
                    countElements[elements[i]]++;
                }
            }

            List<string> result = new List<string>(); 

            foreach (var element in countElements)
            {
                if (element.Value % 2 != 0)
                {
                    result.Add(element.Key);
                }
            }
            Console.WriteLine(string.Join(", ",result));

            Console.WriteLine();
            */
            /*
            double[] input = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
            SortedDictionary<double, int> numbers = new SortedDictionary<double, int>();

            for (int i = 0; i < input.Length; i++)
            {
                if (!numbers.ContainsKey(input[i]))
                {
                    numbers.Add(input[i],1);
                }
                else
                {
                    numbers[input[i]]++;
                }
            }

            foreach (var number in numbers)
            {
                Console.WriteLine($"{number.Key} -> {number.Value}");
            }
            */

        }
    }
}
