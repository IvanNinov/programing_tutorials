﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Emails
{
    class Program
    {
        static void Main(string[] args)
        {
            var personInfo = new Dictionary<string, string>();

            while (true)
            {
                string person = Console.ReadLine();
                if (person == "stop")
                    break;
                string email = Console.ReadLine();

                if (!personInfo.ContainsKey(person))
                {
                    personInfo.Add(person, "");
                }
                personInfo[person] += email;

                if (email.EndsWith("us") || email.EndsWith("uk"))
                {
                    personInfo.Remove(person,out email);
                }
            }
            foreach (var resource in personInfo)
            {
                Console.WriteLine($"{resource.Key} -> {resource.Value}");
            }
        }
    }
}
