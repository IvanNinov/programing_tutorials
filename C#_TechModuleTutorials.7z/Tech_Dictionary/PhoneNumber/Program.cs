﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PhoneNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] commands = Console.ReadLine().Split(" ").ToArray();
            var telephoneNumbers = new SortedDictionary<string,string>();

            while (commands[0] != "END")
            {
                string option = commands[0];

                if (option == "A")
                {
                    string name = commands[1];
                    string number = commands[2];
                    if (!telephoneNumbers.ContainsKey(name))
                    {
                        telephoneNumbers.Add(name, number);
                    }
                    else
                    {
                        telephoneNumbers.Remove(name);
                        telephoneNumbers.Add(name, number);
                    }                  
                }
                else if (option == "S")
                {
                    string name = commands[1];
                    if (telephoneNumbers.ContainsKey(name))
                    {
                        foreach (var telephone in telephoneNumbers)
                        {
                            if (telephone.Key == name)
                            {
                                Console.WriteLine($"{telephone.Key} -> {telephone.Value}");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Contact {name} does not exist.");
                    }
                    
                }
                else if (option == "ListAll")
                {
                    foreach (var telephone in telephoneNumbers)
                    {
                        Console.WriteLine($"{telephone.Key} -> {telephone.Value}");
                    }
                }
                commands = Console.ReadLine().Split(" ").ToArray();
            }


        }
    }
}
