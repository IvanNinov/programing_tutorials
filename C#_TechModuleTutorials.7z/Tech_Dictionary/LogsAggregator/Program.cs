﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LogsAggregator
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Dictionary<string, int>> UserIpInfo = new Dictionary<string, Dictionary<string, int>>();
            Dictionary<string, int> totalSec = new Dictionary<string, int>();

            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split(" ");
                string user = input[1];
                string ip = input[0];
                int sec = int.Parse(input[2]);

                if (!UserIpInfo.ContainsKey(user))
                {
                    UserIpInfo.Add(user,new Dictionary<string,int>());
                    totalSec.Add(user, 0);
                }

                if (!UserIpInfo[user].ContainsKey(ip))
                {
                    UserIpInfo[user].Add(ip, 0);
                }
                UserIpInfo[user][ip] += sec;
                totalSec[user] += sec;
            }
            foreach (var user in totalSec.OrderBy(c => c.Key))
            {
                string output = $"{user.Key}: {user.Value} [";               
                Dictionary<string, int> ipVal = UserIpInfo[user.Key].OrderBy(c => c.Key)
                    .ToDictionary(x=> x.Key,x=> x.Value);

                List<string> ipAdres = new List<string>();
                foreach (var item in ipVal)
                {
                    ipAdres.Add(item.Key);
                }
                Console.Write(output);
                Console.Write(string.Join(", ",ipAdres));
                Console.WriteLine("]");
            }
        }
    }
}
