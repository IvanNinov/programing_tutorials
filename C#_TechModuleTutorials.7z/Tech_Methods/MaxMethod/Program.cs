﻿using System;

namespace MaxMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());


            int result = GetMax(a , b);
            result = GetMax(result,c);

            Console.WriteLine($"{result}");
        }

        static int GetMax(int num1, int num2)
        {
            int result = 0;

            if (num1 > num2)
            {
                result = num1;
            }
            else if (num1 < num2)
            {
                result = num2;
            }

            return result;
        }
    }
}
