﻿using System;

namespace LineLonger
{
    class Program
    {
        static void Main(string[] args)
        {
            double x1 = double.Parse(Console.ReadLine());
            double y1 = double.Parse(Console.ReadLine());
            double x2 = double.Parse(Console.ReadLine());
            double y2 = double.Parse(Console.ReadLine());
            // "(X1, Y1)(X2, Y2)" 

            double x3 = double.Parse(Console.ReadLine());
            double y3 = double.Parse(Console.ReadLine());
            double x4 = double.Parse(Console.ReadLine());
            double y4 = double.Parse(Console.ReadLine());
            // "(X3, Y3)(X4, Y4)" 

            double  first = CenterPoint(x1,y1,x2,y2);
            double second = CenterPoint(x3, y3, x4, y4);

            if (first >= second)
            {
                bool check = CloserPointToCenter(x1, y1, x2, y2);
                if (!check)
                {
                    Console.WriteLine($"({x2}, {y2})({x1}, {y1})");
                    return;
                }
                Console.WriteLine($"({x1}, {y1})({x2}, {y2})");

            }
            else
            {
                bool check = CloserPointToCenter(x3, y3, x4, y4);
                if (!check)
                {
                    Console.WriteLine($"({x4}, {y4})({x3}, {y3})");
                    return;
                }
                Console.WriteLine($"({x3}, {y3})({x4}, {y4})");
            }

        }


        static double CenterPoint(double x1, double y1, double x2, double y2)  //returns whole lenght of line
        {
            double firstPoint = Math.Abs(x1) + Math.Abs(y1);
            double secondPoint = Math.Abs(x2) + Math.Abs(y2);

            double valid = firstPoint + secondPoint;
            return valid;
        }

        static bool CloserPointToCenter(double x1, double y1, double x2, double y2)  // if (x1,y1) is closer else ...
        {
            double firstPoint = Math.Abs(x1) + Math.Abs(y1);
            double secondPoint = Math.Abs(x2) + Math.Abs(y2);

            bool valid = true;

            if (firstPoint <= secondPoint)
            {
                return valid;
            }
            else
            {
                valid = false;
                return valid;
            }
            
        }


    }
}
