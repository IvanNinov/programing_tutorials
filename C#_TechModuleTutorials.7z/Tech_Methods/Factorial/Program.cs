﻿using System;
using System.Numerics;

namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger num = BigInteger.Parse(Console.ReadLine());
            int cnt = 0;
            num = Factorial(num);
            cnt = CountZero(num);
            Console.WriteLine($"{cnt}");
        }


        static BigInteger Factorial(BigInteger n)
        {
            BigInteger result = 1;       
            for (int i = 1; i <= n; i++)
            {
                result = i * result;
            }     
            return result;
        }

        static int CountZero(BigInteger n)
        {
            BigInteger count = n;
            int cnt = 0;

            while (count >= 0)
            {
                
                if (count % 10 != 0)
                {
                    return cnt;
                }
                cnt++;
                count /= 10;
            }
            return cnt;

        }
    }
}
