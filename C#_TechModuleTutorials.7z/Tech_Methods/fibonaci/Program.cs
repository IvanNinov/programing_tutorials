﻿using System;

namespace fibonaci
{
    class Program
    {
        static void Main(string[] args)
        {
            int result = Fib(int.Parse(Console.ReadLine()));
            Console.WriteLine($"{result}");
        }

        static int Fib(int number)
        {
            int result = 0;

            if (number == 0 || number == 1)
            {
                result = 1;
                return result;
            }
            int preNumb = 1;
            int prePreNumb = 1;
            for (int i = 2; i <= number; i++)
            {
                result = preNumb + prePreNumb;
                prePreNumb = preNumb;
                preNumb = result;
            }


            return result;
        }
    }
}
