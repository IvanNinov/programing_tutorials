﻿using System;

namespace Cube
{
    class Program
    {
        static void Main(string[] args)
        {
            var side = double.Parse(Console.ReadLine());
            var result = 0.00d;
            var parameter = Console.ReadLine();

            if (parameter == "face")
            {
                result = FaceDiagonal(side);
            }
            else if (parameter == "space")
            {
                result = SpaceDiagonal(side);
            }
            else if (parameter == "volume")
            {
                result = Volume(side);
            }
            else 
            {
                result = SurfaceArea(side);
            }
            Console.WriteLine($"{result:F2}");
            //face diagonal = sqrt(2*(s*s))
            //space diagonal = sqrt(3*(s*s))
            //volume = s*s*s
            //area = 6 * (s*s)
        }

        static double FaceDiagonal(double side)
        {
            double face = 0.00;
            face = Math.Sqrt(2 * Math.Pow(side,2));
            return face;
        }

        static double SpaceDiagonal(double side)
        {
            double space = 0.00;
            space = Math.Sqrt(3 * Math.Pow(side, 2));
            return space;
        }

        static double SurfaceArea(double side)
        {
            double area = 0.00;
            area = 6 * Math.Pow(side, 2);
            return area;
        }

        static double Volume(double side)
        {
            double volume = 0.00;
            volume = Math.Pow(side, 3);
            return volume;
        }

    }
}
