﻿using System;

namespace Master
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());

            for (int i = 1; i <= number; i++)
            {
                if (IsPalindrom(i) && DividedBySeven(i) && Even(i))
                {
                    Console.WriteLine($"{i}");
                }
            }


        }

        static bool IsPalindrom(int n)
        {
            string valueAsString = n.ToString();
            bool check = true;

            for (int i = 0; i < valueAsString.Length/2; i++)
            {
                if (valueAsString[i] != valueAsString [valueAsString.Length - 1 - i])
                {
                    check = false;
                    break;
                }
            }
        
            return check;
        }

        static bool DividedBySeven(int num)
        {
            bool check = false;
            int lastDigit = 0;
            int sum = 0;
            while (num > 0)
            {
                lastDigit = num % 10;
                num = num / 10;
                sum += lastDigit;
            }
            if (sum % 7 == 0)
            {
                check = true;
            }
            return check;
        }

        static bool Even(int num)
        {
            bool check = false;
            int lastDigit = 0;
            while (num > 0)
            {
                lastDigit = num % 10;
                num = num / 10;
                if (lastDigit % 2 == 0)
                {
                    check = true;
                }
            }

            return check;
        }


    }
}
