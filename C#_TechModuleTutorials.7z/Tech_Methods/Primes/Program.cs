﻿using System;

namespace Primes
{
    class Program
    {
        static void Main(string[] args)
        {
            long num = long.Parse(Console.ReadLine());
            bool check = IsPrime(num);
            if (num == 0 || num == 1)
            {
                Console.WriteLine("False");
                return;
            }
            Console.WriteLine(check);
        }

        static bool IsPrime(long n)
        {
            bool isPrime = true;

            int count = 2;
            while (count <= Math.Sqrt(n))
            {
                if (n % count == 0)
                {
                    isPrime = false;
                    break;
                }
                count++;
            }


            return isPrime;
        }
    }
}
