﻿using System;

namespace FigureArea
{
    class Program
    {
        static void Main(string[] args)
        {
            var type = Console.ReadLine().ToLower();
            double result = 0;
            if (type == "triangle")
            {
                double fSide = double.Parse(Console.ReadLine());
                double sSide = double.Parse(Console.ReadLine());
                result = AreaTriangle(fSide,sSide);
            }
            else if (type == "square")
            {
                double side = double.Parse(Console.ReadLine());
                result = AreaSquere(side);
            }
            else if (type == "rectangle")
            {
                double width = double.Parse(Console.ReadLine());
                double side = double.Parse(Console.ReadLine());
                result = Area(width, side);
            }
            else
            {
                double radius = double.Parse(Console.ReadLine());
                result = Area(radius);
            }
            Console.WriteLine($"{result:F2}");
        }

        static double AreaTriangle(double par1, double par2)
        {
            double area = 0.5 * (par1 * par2);
            return area;
        }
        static double AreaSquere(double side)
        {
            double area = 0;
            return  area = Math.Pow(side,2);
        }
        static double Area(double width, double side)
        {
            double area = 0;
            return area = width*side;
        }
        static double Area(double radius)
        {
            double area = 0;
            return area = Math.PI * Math.Pow(radius,2);
        }
    }
}
