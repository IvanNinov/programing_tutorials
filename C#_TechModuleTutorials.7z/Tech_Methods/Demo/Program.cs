﻿using System;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Heather();
            Body();
            Footer();

        }

         static void Heather()
        {
            Console.WriteLine("CASH RECEIPT");
            Console.WriteLine("------------------------------");
        }
        static void Body()
        {
            Console.WriteLine("Charged to____________________");
            Console.WriteLine("Received by____________________");
        }
        static void Footer()
        {
            Console.WriteLine("------------------------------");
            Console.WriteLine("© SoftUni");

        }
    }
}
