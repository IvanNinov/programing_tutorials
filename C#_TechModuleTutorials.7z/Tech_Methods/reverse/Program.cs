﻿using System;
using System.Linq;

namespace reverse
{
    class Program
    {
        static void Main(string[] args)
        {
            double d = double.Parse(Console.ReadLine());
            string number = ReverseDigit(d);
            Console.WriteLine($"{number}");
        }

        static string ReverseDigit(double number)
        {
            string reversedStr = new string(number.ToString().Reverse().ToArray());
            double reversedDouble;
            if (double.TryParse(reversedStr, out reversedDouble))
            {
                return reversedStr;
            }
            else
            {
                return null;
            }
        }
    }
}
