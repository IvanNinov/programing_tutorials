﻿using System;

namespace HelloPete
{
    class Program
    {
        static void Main(string[] args)
        {
            HelloPete(Console.ReadLine()); 
        }

        static void HelloPete(string Name)
        {
            Console.WriteLine($"Hello, {Name}!");
        }

    }
}
