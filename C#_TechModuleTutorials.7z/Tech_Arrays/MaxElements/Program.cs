﻿using System;

namespace MaxElements
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();
            int len = 0;
            int bestLen = 0;
            int start = 0;
            var stringNumbers = text.Split(
                ' ', StringSplitOptions.RemoveEmptyEntries);
            int[] toNumbers = new int[stringNumbers.Length];

            for (int i = 0; i < stringNumbers.Length; i++)
            {
                toNumbers[i] = int.Parse(stringNumbers[i]);
            }

            for (int i = 0; i < toNumbers.Length-1; i++)
            {
                    if (toNumbers[i] < toNumbers[i+1])
                    {
                        len++;
                        if (bestLen < len)
                        {
                            start = i - len;
                            bestLen = len;
                        }

                    }
                    else
                    {
                        len = 0;
                    }            
                
            }

            for (int i = start + 1; i <= start + bestLen + 1; i++)
            {
                Console.Write($"{toNumbers[i]} ");
            }
            Console.WriteLine();


        }
    }
}
