﻿using System;

namespace MostFrequentNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();

            var stringNumbers = text.Split(
                ' ', StringSplitOptions.RemoveEmptyEntries);
            int[] toNumbers = new int[stringNumbers.Length];
            for (int i = 0; i < stringNumbers.Length; i++)
            {
                toNumbers[i] = int.Parse(stringNumbers[i]);
            }

            int freqNumber = CountEvenNumbers(toNumbers);
            Console.WriteLine($"{freqNumber}");
        }

        static int CountEvenNumbers(int[] numbers)
        {
            int count = 0;
            int countBigest = 0;
            int number = 0;

            for (int i = 0; i < numbers.Length; i++)
            {
                for (int j = 0; j < numbers.Length; j++)
                {
                    if (numbers[i] == numbers[j])
                    {
                        count++;
                    }
                }
                if (countBigest < count)
                {
                    number = numbers[i];
                    countBigest = count;
                }
                count = 0;
            }
            return number;
        }
    }
}
