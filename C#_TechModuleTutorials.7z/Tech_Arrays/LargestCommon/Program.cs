﻿using System;

namespace LargestCommon
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] inputFirst = Console.ReadLine().Split();
            string[] inputSecond = Console.ReadLine().Split();

            int minWidth = Math.Min(inputFirst.Length,inputSecond.Length);

            int countLeft = 0;
            int countRight = 0;

            for (int i = 0; i < minWidth; i++)
            {
                if (inputFirst[i] == inputSecond[i])
                {
                    countLeft++;
                }

                if (inputFirst[inputFirst.Length -1 - i] ==
                    inputSecond[inputSecond.Length - 1 - i] )
                {
                    countRight++;
                }
            }
            Console.WriteLine(Math.Max(countLeft,countRight));
        }
    }
}
