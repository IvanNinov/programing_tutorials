﻿using System;

namespace Enew
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();
            int result = 0;
            bool cmp = false;
            string[] line = text.Split(
                ' ', StringSplitOptions.RemoveEmptyEntries);

            int[] number = new int[line.Length];
            for (int i = 0; i <= line.Length - 1; i++)
            {
                number[i] = int.Parse(line[i]);
            }
            result = Ret(number, ref cmp);
            if (cmp == true)
            {
                Console.WriteLine($"{result}");
            }
            else
            {
                Console.WriteLine($"no");
            }

        }

        
        static int Ret(int[] number, ref bool cmp)
        {
            int leftSum = 0;
            int rightSum = 0;
            int position = 0;

            for (int i = 0; i < number.Length; i++)
            {


                if (i == 0 && number.Length == 1)
                {
                    leftSum = 0;
                    rightSum = 0;
                    if (leftSum == rightSum)
                    {
                        position = i;
                        cmp = true;
                        return position;
                    }
                }
                for (int j = i + 1; j < number.Length; j++)
                {
                    
                    rightSum += number[j];

                }
                if (leftSum == rightSum)
                {
                    position = i;
                    cmp = true;
                    return position;
                }
                rightSum = 0;
                leftSum += number[i];
            }
            return position;
        }
    }
}
