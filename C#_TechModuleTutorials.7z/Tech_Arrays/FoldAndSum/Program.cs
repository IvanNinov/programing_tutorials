﻿using System;

namespace FoldAndSum
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();        //"4 3 -1 2 5 0 1 9 8 6 7 -2";  // 5 2 3 6   4 3 -1 2 5 0 1 9 8 6 7 -2     1 2 3 4 5 6 7 8
            var stringNumbers = text.Split(
                ' ', StringSplitOptions.RemoveEmptyEntries);
            int[] toNumbers = new int[stringNumbers.Length];
            for (int i = 0; i < stringNumbers.Length; i++)
            {
                toNumbers[i] = int.Parse(stringNumbers[i]);
            }

            int k = toNumbers.Length / 4;
            int[] result = Fold(toNumbers,k);
            int[] resultTrim = Trim(toNumbers, k);

            for (int i = 0; i < result.Length; i++)
            {
                result[i] = result[i] + resultTrim[i];
            }
            Console.WriteLine(string.Join(' ',result));


        }

        static int[] Trim(int[] arr,int k)
        {
            int[] result = new int[k*2];
            for (int i = 0; i < k; i++)
            {
                result[i] = arr[k + i];
                result[i + k] = arr[2 * k + i];

            }
            return result;
        }

        static int[] Fold(int[] arr, int k)
        {
            int[] result = new int[k * 2];
            for (int i = 0; i < k; i++)
            {
                result[i] = arr[k - i - 1];
                
                result[k + i] = arr[arr.Length - i - 1];              
            }
            return result;
        }
    }
}
