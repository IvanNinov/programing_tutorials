﻿using System;
using System.Linq;

namespace IncrNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "0 1 1 2 2 3 3";

            var stringNumbers = text.Split(
                ' ', StringSplitOptions.RemoveEmptyEntries);
            int[] toNumbers = new int[stringNumbers.Length];
            for (int i = 0; i < stringNumbers.Length; i++)
            {
                toNumbers[i] = int.Parse(stringNumbers[i]);
            }
            int[] reverseNumbers = new int[toNumbers.Length];
            reverseNumbers = toNumbers.Reverse().ToArray();

            Tuple<int, int> positions = BotPosition(reverseNumbers);

            for (int i = positions.Item1; i < positions.Item1 + positions.Item2; i++)
            {
                Console.Write($"{toNumbers[i]}");
            }
        }

        static Tuple <int,int> BotPosition(int[] numbers)
        {
            int position = 0;
            int lPosition = 0;
            int count = 0;
            int bCount = 0;
            //6 5 4 3 
            for (int i = 0; i < numbers.Length; i++)
            {
                for (int j = i; j < numbers.Length; j++)
                {
                    if (numbers[i] > numbers[j])
                    {
                        count++;
                        position = i;
                    }
                    if (numbers[i] < numbers[j])
                    {
                        break;
                    }
                }
                if (bCount <= count)
                {
                    bCount = count;
                    lPosition = position;
                }
                count = 0;
            }

            return Tuple.Create(lPosition,bCount);
        }

    }
}
