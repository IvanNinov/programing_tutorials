﻿using System;
using System.Linq;

namespace RotateTheSum
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] input = Console.ReadLine().Split(' ',StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            int rotate = int.Parse(Console.ReadLine());

            int[] sum = new int[input.Length];

            for (int i = 0; i < rotate; i++)
            {
                int[] rotated = RotateRight(input);

                for (int j = 0; j < sum.Length; j++)
                {
                    sum[j] += rotated[j];
                }
                input = rotated;
            }


            foreach (var item in sum)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
        }

        static int[] RotateRight(int[] arr)
        {
            int lastElement = arr[arr.Length - 1];
            int[] rotated = new int[arr.Length];
            rotated[0] = lastElement;
            for (int i = 1; i < arr.Length; i++)
            {
                rotated[i] = arr[i - 1];
            }
            return rotated;
        }       
    }
}
