﻿using System;
using System.Linq;

namespace EqualSums
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();       
            string[] line = text.Split(
                ' ', StringSplitOptions.RemoveEmptyEntries);

            int[] number = new int[line.Length];
            for (int i = 0; i <= line.Length - 1; i++)
            {
                number[i] = int.Parse(line[i]);  
            }
            int dif = int.Parse(Console.ReadLine());


            int cmp = Pairs(number,dif);
            Console.WriteLine($"{cmp}");
        }  

        static int Pairs(int[] number, int dif)
        {
            int cmp = 0;
            int first = 0;
            int second = 0;
            for (int i = 0; i < number.Length; i++)
            {
                first = number[i];
                for (int j = 0; j < number.Length; j++)
                {
                    second = number[j];
                    if (first + dif == second)
                    {
                        cmp++;
                    }
                }
            }
            return cmp;
        }
    }
}
