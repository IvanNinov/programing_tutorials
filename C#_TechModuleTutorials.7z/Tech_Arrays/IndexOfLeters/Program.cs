﻿using System;

namespace IndexOfLeters
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();
            char[] txt = text.ToCharArray();
            
            char[] alfa = new char[26];
            for (int i = 0; i < alfa.Length; i++)
            {
                alfa[i] = (char)(i + 97) ;
            }
 
            for (int i = 0; i < txt.Length; i++)
            {
                for (int j = 0; j < alfa.Length; j++)
                {
                    if (txt[i] == alfa[j])
                    {
                        Console.WriteLine($"{alfa[j]} -> {j}");
                    }
                }
            }
        }
    }
}
