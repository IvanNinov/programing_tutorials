﻿using System;
using System.Text.RegularExpressions;
using System.Collections.Specialized;

namespace ExtractByKey
{
    class Program
    {
        static void Main(string[] args)
        {
            string key = Console.ReadLine().ToLower();
            string input = Console.ReadLine();
             Regex pat = new Regex($@"\b[^!.?]*(\b{key}\b).*?(?=[.!?])");
            //var pat = @"\b([key]+)\b";
            //var patern = pat.Replace("key",key);
            MatchCollection paternAll = pat.Matches(input);
                foreach (Match p in paternAll)
                {
                    if (p.Success==true)
                    {
                        Console.WriteLine(p);
                    }

                }
            
            //\b[^!\.\?;]*(?:[to]+)[^!\.\?;]*\b
            //\b[^!.?;]*(\w*)[^!.?;]*\b
        }
    }
}
