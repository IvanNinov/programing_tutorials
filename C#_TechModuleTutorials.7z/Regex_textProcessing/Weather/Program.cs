﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Weather
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, List<string>> CityTemp = new Dictionary<string, List<string>>();

            Regex regex = new Regex(@"([A-Z][A-Z])([0-9]*\.[0-9]*)([a-zA-Z]+)(?=[\|])");
            MatchCollection Amatches;
            string input = Console.ReadLine();       
            while(input != "end")
            {
                Match OneMatch = regex.Match(input);
                if (OneMatch.Success)
                {
                    string city = OneMatch.Groups[1].Value;
                    string value = OneMatch.Groups[2].Value;
                    string wather = OneMatch.Groups[3].Value;
                    if (!CityTemp.ContainsKey(city))
                    {
                        CityTemp.Add(city, new List<string>());
                        CityTemp[city].Add(wather);
                        CityTemp[city].Add(value);
                    }
                    CityTemp[city][0] = wather;
                    CityTemp[city][1] = value;
                }            
                input = Console.ReadLine();
            }
            foreach (var collection in CityTemp.OrderBy(x=>x.Value[1]))
            {
                Console.WriteLine($"{collection.Key} => {double.Parse(collection.Value[1]):F2} => {collection.Value[0]}");
            }
        }
    }
}
