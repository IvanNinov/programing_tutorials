﻿using System;
using System.Text.RegularExpressions;

namespace extractEmails
{
    class Program
    {
        static void Main(string[] args)
        {
            //string input = Console.ReadLine();
            string text = Console.ReadLine();
            Regex regex = new Regex(@"(?<= )[A-Za-z0-9]+([.\-_][A-Za-z0-9]+)*@[A-Za-z]+([.\-_][A-Za-z]+)*(\.[A-Za-z]+)+");

            MatchCollection allValid = regex.Matches(text);
            foreach (Match match in allValid)
            {
                Console.WriteLine(match);
            }
        }
    }
}
