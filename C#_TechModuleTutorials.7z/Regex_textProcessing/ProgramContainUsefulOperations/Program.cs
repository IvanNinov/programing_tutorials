﻿using System;
using System.Text.RegularExpressions;
using System.Collections.Specialized;

namespace ProgramContainUsefulOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstText = @"apple:green:3 banana:yellow:5";
            var myRegex = new Regex(@"(\w+):(\w+):(\d+)");

            //Is there a match?
            Console.WriteLine("*** Is there a match? ***");
            if (myRegex.IsMatch(firstText))    // IsMatch
            {
                Console.WriteLine("YES");
            }
            else
            {
                Console.WriteLine("NO");
            }

            //How many matches are there?
            MatchCollection AllMatches = myRegex.Matches(firstText);
            Console.WriteLine("*** Number of Matches ***");
            Console.WriteLine(AllMatches.Count);

            // Task 3: What is the first match?
            Console.WriteLine("\n" + "*** First Match ***");
            Match OneMatch = myRegex.Match(firstText);
            if (OneMatch.Success)
            {
                Console.WriteLine("Overall Match: " + OneMatch.Groups[0].Value);
                Console.WriteLine("Group 1: " + OneMatch.Groups[1].Value);
                Console.WriteLine("Group 2: " + OneMatch.Groups[2].Value);
                Console.WriteLine("Group 3: " + OneMatch.Groups[3].Value);
            }
            // Task 4: What are all the matches?
            Console.WriteLine("\n" + "*** Matches ***");
            if (AllMatches.Count > 0)
            {
                foreach (Match SomeMatch in AllMatches)
                {
                    Console.WriteLine("Overall Match: " + SomeMatch.Groups[0].Value);
                    Console.WriteLine("Group 1: " + SomeMatch.Groups[1].Value);
                    Console.WriteLine("Group 2: " + SomeMatch.Groups[2].Value);
                    Console.WriteLine("Group 3: " + SomeMatch.Groups[3].Value);
                }
            }
            string replaced = myRegex.Replace(firstText, delegate (Match m)
             {
                 return m.Groups[3].Value + ":" +
                        m.Groups[2].Value + ":" +
                        m.Groups[1].Value;
             }
             );
            Console.WriteLine(replaced);

            string[] splits = Regex.Split(firstText, @":|\s");
            Console.WriteLine("\n" + "*** Splits ***");
            foreach (string split in splits) Console.WriteLine(split);

        }
    }
}
