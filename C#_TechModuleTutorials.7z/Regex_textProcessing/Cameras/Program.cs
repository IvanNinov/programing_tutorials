﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Cameras
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] numbers = Console.ReadLine().Split();
            int m = int.Parse(numbers[0]);
            int n = int.Parse(numbers[1]);
            string input = Console.ReadLine();

            Regex regex = new Regex(@"\|<(?<picture>\w+)");
            MatchCollection matches = regex.Matches(input);
            List<string> words = new List<string>();
            foreach (Match match in matches)
            {
                string currentMatch = match.Groups["picture"].Value;
                char[] bricks = currentMatch.Skip(m).Take(n).ToArray();
                string currRes = string.Join("",bricks);
                words.Add(currRes);
            }
            Console.WriteLine(string.Join(", ",words));



        }
    }
}
