﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace KeyReplacer
{
    class Program
    {
        static void Main(string[] args)
        {
            string key = Console.ReadLine();
            string text = Console.ReadLine();
            //((?<=[\|<\\])|^)[a-zA-Z]+(?=$)   end
            //(?<=^)[a-zA-Z]+?(?=[\|<\\])      start
            //((?<=[\|<\\])|^)[a-zA-Z]+((?=[\|<\\])|$)
            List<string> startStopContainer = new List<string>();
            Regex regexStart = new Regex(@"(?<=^)[a-zA-Z]+?(?=[\|<\\])");
            Regex regexEnd = new Regex(@"((?<=[\|<\\])|^)[a-zA-Z]+(?=$)");
            Match startPosition = regexStart.Match(key);
            Match endPosition = regexEnd.Match(key);
            string start = startPosition.ToString();
            string end = endPosition.ToString();
            //((?<=start)(?!end).*?(?!start)(?=(end)))
            //((?<={start}).*?(?=({end})))
            Regex regexReplacer = new Regex($@"((?<={start})(?!{end}).*?(?!{start})(?=({end})))");
            MatchCollection MatchesInText = regexReplacer.Matches(text);
            StringBuilder ResultString = new StringBuilder();
            foreach (Match match in MatchesInText)
            {
                if (match.Success)
                {
                    if (match.ToString().Length == 0)
                    {
                        Console.WriteLine("Empty result");
                        return;
                    }
                    ResultString.Append(match);
                }
                
            }
            if (ResultString.Length == 0)
            {
                Console.WriteLine("Empty result");
            }
            else
            {
                Console.WriteLine(ResultString);
            }

        }
    }
}
