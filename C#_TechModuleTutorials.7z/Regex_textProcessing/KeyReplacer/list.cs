﻿namespace KeyReplacer
{
    internal class list<T>
    {
    }
}