﻿using System;

namespace Divided3
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            int product = 0;
            int count = int.Parse(Console.ReadLine());

            do
            {
                product = number * count;
                Console.WriteLine($"{number} X {count} = {product}");
                count++;
            } while (count <= 10);

        }
    }
}
