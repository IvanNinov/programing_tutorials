﻿using System;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 3;
            int b = 6;
            Console.WriteLine(a < b);
            Console.WriteLine(a <= b);
            Console.WriteLine(a >= b);
            Console.WriteLine(a > b);
            Console.WriteLine(a == b);

            Console.WriteLine(4%6);

            Console.ReadKey();
        }
    }
}
