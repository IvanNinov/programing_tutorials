﻿using System;

namespace Hotel
{
    class Program
    {
        static void Main(string[] args)
        {
            string month = Console.ReadLine();
            int nightCounts = int.Parse(Console.ReadLine());
            double priceS = 0.0;
            double priceD = 0.0;
            double priceSuite = 0.0;

            switch (month)
            {
                case "May":
                case "October":
                    priceS = 50 * nightCounts;
                    priceD = 65 * nightCounts;
                    priceSuite = 75 * nightCounts;
                    if (nightCounts > 7)
                    {
                        priceS = priceS * 0.95;

                        if (month == "October")
                        {
                            
                            priceS -= 50 * 0.95; //FUCK
                        }
                    }
                    break;
                case "June":
                case "September":
                    priceS = 60 * nightCounts;
                    priceD = 72 * nightCounts;
                    priceSuite = 82 * nightCounts;
                    if (nightCounts > 14)
                    {
                        priceD = priceD * 0.9;
                    }
                    if (nightCounts > 7 && month == "September")
                    {
                        priceS -= 60;
                    }
                    break;
                case "July":
                case "August":
                case "December":
                    priceS = 68 * nightCounts;
                    priceD = 77 * nightCounts;
                    priceSuite = 89 * nightCounts;
                    if (nightCounts > 14)
                    {
                        priceSuite = priceSuite * 0.85;
                    }
                    break;
            }
            Console.WriteLine($"Studio: {priceS:F2} lv.");
            Console.WriteLine($"Double: {priceD:F2} lv.");
            Console.WriteLine($"Suite: {priceSuite:F2} lv.");



        }
    }
}
