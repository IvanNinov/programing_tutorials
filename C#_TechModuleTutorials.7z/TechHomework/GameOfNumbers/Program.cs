﻿using System;

namespace GameOfNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int m = int.Parse(Console.ReadLine());
            int magicNumber = int.Parse(Console.ReadLine());
            int count = 0;
            int counts = 0;
            int lastNumF = 0;
            int lastnumberS = 0;

 
            forLoop(ref counts, magicNumber, n, m, ref lastNumF, ref lastnumberS);

            for (int i = n; i <= m; i++)
            {
                for (int j = n; j <= m; j++)
                {
                    count++;
                }
            }
            if (counts == 1)
            {
                Console.WriteLine($"Number found! {lastNumF} + {lastnumberS} = {magicNumber}");
            }
            else
            {
                Console.WriteLine($"{count} combinations - neither equals {magicNumber}");
            }

        }

        private static void forLoop(ref int counts, int magicNumber,  int n, int m , ref int lastNumF , ref int lastnumberS )
        {
            for (int j = m; j >= n; j--)
            {
                for (int i = n; i <= m; i++)
                {
                    if (j + i == magicNumber)
                    {
                        lastNumF = j;
                        lastnumberS = i;
                        counts = 1;
                        return;
                    }
                }
            }
        }
    }
}
