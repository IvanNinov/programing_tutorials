﻿using System;

namespace Interval
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int m = int.Parse(Console.ReadLine());
            int maxInterval = 0;
            int minInterval = 0;
            if (n > m)
            {
                maxInterval = n;
                minInterval = m;
            }
            else
            {
                maxInterval = m;
                minInterval = n;
            }


            for (int i = minInterval; i <= maxInterval; i++)
            {
                Console.WriteLine($"{i}");
            }
        }
    }
}
