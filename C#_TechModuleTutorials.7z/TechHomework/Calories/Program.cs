﻿using System;

namespace Calories
{
    class Program
    {
        static void Main(string[] args)
        {
            int ingredientsNumber = int.Parse(Console.ReadLine());
            double totalCalories = 0.0;
            for (int i = 0; i < ingredientsNumber; i++)
            {
                string ingredient = Console.ReadLine().ToLower();

                switch (ingredient)
                {
                    case "cheese":
                        totalCalories += 500;
                        break;
                    case "salami":
                        totalCalories += 600;
                        break;
                    case "tomato sauce":
                        totalCalories += 150;
                        break;
                    case "pepper":
                        totalCalories += 50;
                        break;
                    default:
                        break;
                }

            }
            Console.WriteLine($"Total calories: {totalCalories}");
        }
    }
}
