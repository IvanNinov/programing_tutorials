﻿using System;

namespace ChoseAdrink
{
    class Program
    {
        static void Main(string[] args)
        {
            string profesion = Console.ReadLine();
            int quantity = int.Parse(Console.ReadLine());
            switch (profesion)
            {
                case "Athlete":
                    Console.WriteLine($"The {profesion} has to pay {(quantity * 0.70):F2}.");
                    break;
                case "Businessman":
                case "Businesswoman":
                    Console.WriteLine($"The {profesion} has to pay {(quantity * 1.00):F2}.");
                    break;
                case "SoftUni Student":
                    Console.WriteLine($"The {profesion} has to pay {(quantity * 1.70):F2}.");
                    break;
                default:
                    Console.WriteLine($"The {profesion} has to pay {(quantity * 1.20):F2}.");
                    break;
            }
        }
    }
}
