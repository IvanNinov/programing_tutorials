﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Restaurant
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());
            string package = Console.ReadLine();

            double price = 0;
            string hallName;
            double disc = 0.0;

            if (size <= 50)
            {
                hallName = "Small Hall";
                price += 2500;
            }
            else if (size > 50 && size <= 100)
            {
                hallName = "Terrace";
                price += 5000;
            }
            else if (size > 100 && size <= 120)
            {
                hallName = "Great Hall";
                price += 7500;
            }
            else
            {
                Console.WriteLine("We do not have an appropriate hall.");
                hallName = "null";
                return;
            }




            switch (package)
            {
                case "Normal":
                    price = price + 500;
                    disc = 0.05;
                    break;
                case "Gold":
                    price = price + 750;
                    disc = 0.1;
                    break;
                case "Platinum":
                    price = price + 1000;
                    disc = 0.15;
                    break;
            }

            price = price - (price * disc);


            Console.WriteLine($"We can offer you the {hallName}");
            Console.WriteLine($"The price per person is {price / size:F2}$");

        }
    }
}
