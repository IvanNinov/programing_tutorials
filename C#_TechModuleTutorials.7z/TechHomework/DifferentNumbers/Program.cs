﻿using System;
using System.Collections.Generic;
namespace DifferentNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            if (b - a < 5)
            {
                Console.WriteLine("No");
                return;
            }

            for (int row = a; row <= b; row++)
            {
                for (int col = a; col <= b; col++)
                {
                    for (int i = a; i <= b; i++)
                    {
                        for (int j = a; j <= b; j++)
                        {
                            for (int k = a; k <= b; k++)
                            {
                                if (a <= row && row < col && col < i && i < j && j < k && k <= b)
                                {
                                    Console.WriteLine($"{row} {col} {i} {j} {k}");
                                }
                            }
                        }
                    }
                }
            }
        }
    }

}
    