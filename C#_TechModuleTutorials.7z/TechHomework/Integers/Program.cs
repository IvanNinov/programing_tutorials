﻿using System;

namespace Integers
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            while (true)
            {
                try
                {
                    int numbers = int.Parse(Console.ReadLine());
                    count++;
                }
                catch (Exception ex)
                {

                    Console.WriteLine($"{count}");
                    break;
                }
                
                
            }
        }
    }
}
