﻿using System;

namespace TestNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int m = int.Parse(Console.ReadLine());
            int sumBoundary =  int.Parse(Console.ReadLine());
            int sumTotal = 0;
            int count = 0;



            forLoop(ref count,ref sumTotal,ref sumBoundary,n,m);

            Console.WriteLine($"{count} combinations");
            if (sumTotal < sumBoundary)
            {
                Console.WriteLine($"Sum: {sumTotal}");
            }
            else
            {
                Console.WriteLine($"Sum: {sumTotal} >= {sumBoundary}");

            }
            

        }
        private static void forLoop(ref int count , ref int sumTotal, ref int sumBoundary, int n, int m)
        {
            for (int i = n; i >= 1; i--)
            {
                for (int j = 1; j <= m; j++)
                {
                    if (sumTotal >= sumBoundary)
                    {
                        return;
                    }
                    count++;
                    sumTotal = sumTotal + 3 * (i * j);
                }
            }
        }
     

    }
}
