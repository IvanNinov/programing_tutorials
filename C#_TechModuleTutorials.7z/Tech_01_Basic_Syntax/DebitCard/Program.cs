﻿using System;
using System.Collections.Generic;

namespace DebitCard
{
    class Program
    {
        static void Main(string[] args)
        {
           
            var arr = new List<string>();
            for (int i = 0; i < 4; i++)         
            {
                int input = int.Parse(Console.ReadLine());
                arr.Add(input.ToString("D4"));
            }

            foreach (var element in arr)
            {
                Console.Write($" {element}");
            }
            Console.WriteLine();

        }
    }
}
