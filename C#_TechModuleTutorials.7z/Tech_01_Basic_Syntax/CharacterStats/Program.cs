﻿using System;

namespace CharacterStats
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = Console.ReadLine();
            int curHealth = int.Parse(Console.ReadLine());
            int maxHealth = int.Parse(Console.ReadLine());
            int curEnergy = int.Parse(Console.ReadLine());
            int maxEnergy = int.Parse(Console.ReadLine());

            string hp = new string('|',curHealth);
            string leftHp = new string('.', maxHealth - curHealth);
            string en = new string('|', curEnergy);
            string leftEn = new string('.', maxEnergy - curEnergy);


            Console.WriteLine($"Name: {name}");
            Console.WriteLine($"Health: |{hp}{leftHp}|");
            Console.WriteLine($"Energy: |{en}{leftEn}|");


        }
    }
}
