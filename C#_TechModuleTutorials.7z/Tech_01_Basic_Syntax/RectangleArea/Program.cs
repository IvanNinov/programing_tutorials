﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RectangleArea
{
    class Program
    {
        static void Main(string[] args)
        {
            double firstNumber = double.Parse(Console.ReadLine());
            //float first = float.Parse(Math.Round(firstNumber,2).ToString());
            double secNumber = double.Parse(Console.ReadLine());
            //float second = float.Parse(Math.Round(secNumber, 2).ToString());

            double result = firstNumber * secNumber;
            Console.WriteLine($"{result:F2}");


        }
    }
}
