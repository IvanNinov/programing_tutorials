﻿using System;
using System.Collections.Generic;

namespace ObjectsDemoDefineObjects
{
    class Program
    {
        public static int Sale { get; private set; }

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            List<Sale> sales = new List<Sale>();

            Dictionary<string, decimal> totalSalesByTime = 
                new Dictionary<string, decimal>();

            for (int i = 0; i < n; i++)
            {
                string[] data = Console.ReadLine().Split();
                string town = data[0];
                string product = data[1];
                decimal price = decimal.Parse(data[2]);
                decimal quantity = decimal.Parse(data[2]);

                //list elements filed here
                Sale sale = new Sale(town,product,price,quantity);
                sales.Add(sale);
            }

            foreach (var sale in sales)
            {
                if (!totalSalesByTime.ContainsKey(sale.Town))
                {
                    totalSalesByTime.Add(sale.Town,sale.Multiply());
                }
                else
                {
                    totalSalesByTime[sale.Town] += sale.Multiply();
                }
            }

            foreach (var item in totalSalesByTime)
            {
                Console.WriteLine($"{item.Key} -> {item.Value:F2}");
            }
        }
    }
}
