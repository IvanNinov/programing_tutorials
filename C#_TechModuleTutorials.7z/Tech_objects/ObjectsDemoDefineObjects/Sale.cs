﻿namespace ObjectsDemoDefineObjects
{
     class Sale
    {
        // class properties  ---------------------------------------------------
        public string Town { get; set; }
        public string Product { get; set; }
        public decimal Price { get; set; }
        public decimal Quantity { get; set; }

        //class constructor  ---------------------------------------------------
        // same name as class

        public Sale(string Town, string Product , decimal Price,decimal Quantity)
        {
            this.Town = Town;
            this.Product = Product;
            this.Price = Price;
            this.Quantity = Quantity;
        }
        //end class constructor  ------------------------------------------------


        //Methods

        public decimal Multiply()
        {
            return Price * Quantity;
        }
        //End of Methods   ------------------------------------------------
    }
}