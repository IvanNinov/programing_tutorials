﻿using System;
using System.Globalization;

namespace ObjectsDemo
{
    class Program
    {
        public static object DataTime { get; private set; }

        static void Main(string[] args)
        {
            //DateTime input = DateTime.ParseExact(Console.ReadLine(),"d-M-yyyy", CultureInfo.InvariantCulture);

            string[] words = Console.ReadLine().Split();

            Random rand = new Random();

            for (int i = 0; i < words.Length; i++)
            {
                string currentWord = words[i];
                int randIndex = rand.Next(0,words.Length - 1);
                words[i] = words[randIndex];
                words[randIndex] = currentWord;
            }
        }


    }
}
