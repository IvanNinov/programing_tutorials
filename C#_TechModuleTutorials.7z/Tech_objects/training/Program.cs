﻿using System;
using System.Numerics;

namespace training
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            BigInteger bestValue = 0;
            int bsnow = 0;
            int btime = 0;
            int bquality = 0;
            for (int i = 0; i < n; i++)
            {
                int snow = int.Parse(Console.ReadLine());
                int time = int.Parse(Console.ReadLine());
                int quality = int.Parse(Console.ReadLine());

                BigInteger value = BigInteger.Pow((snow/time),quality);

                if (bestValue < value)
                {
                    bestValue = value;
                    bsnow = snow;
                    btime = time;
                    bquality = quality;
                }
            }
            Console.WriteLine($"{bsnow} : {btime} = {bestValue} ({bquality})");
        }
    }
}
