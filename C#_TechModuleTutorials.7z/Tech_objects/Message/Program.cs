﻿using System;

namespace Message
{
    class Program
    {
        static void Main(string[] args)
        {

            int input = int.Parse(Console.ReadLine());
            Random generation = new Random();
            string[] phrases = { "Excellent product.", "Such a great product.", "I always use that product.", "Best product of its category.", "Exceptional product.", "I can’t live without this product." };
            string[] events = {"Now I feel good.", "I have succeeded with this product.", "Makes miracles.I am happy of the results!", "I cannot believe but now I feel awesome.", "Try it yourself, I am very satisfied.", "I feel great!"};
            string[] authors = { "Diana", "Petya", "Stella", "Elena", "Katya", "Iva", "Annie", "Eva" };
            string[] cities = { "Burgas", "Sofia", "Plovdiv", "Varna", "Ruse" };
            Message str = new Message(phrases, events, authors, cities);

            for (int i = 0; i < input; i++)
            {
                int pRand = generation.Next(str.phrases.Length);
                int eRand = generation.Next(str.events.Length);
                int aRand = generation.Next(str.author.Length);
                int cRand = generation.Next(str.cities.Length);
                Console.WriteLine($"{str.phrases[pRand]} {str.events[eRand]} {str.author[aRand]} {str.cities[cRand]}.");
            }



        }
    }
    class Message
    {
        public string[] phrases { get; set; }
        public string[] events { get; set; }
        public string[] author { get; set; }
        public string[] cities { get; set; }


        public Message(string[] phrases, string[] events, string[] author, string[] cities)
        {
            this.phrases = phrases;
            this.events = events;
            this.author = author;
            this.cities = cities;
        }

    }
}

   




