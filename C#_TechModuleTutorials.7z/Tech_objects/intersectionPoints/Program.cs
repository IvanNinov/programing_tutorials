﻿using System;
using System.Linq;

namespace intersectionPoints
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle one = GetCircle();
            Circle two = GetCircle();
            Console.WriteLine("Hello World!");
        }



    }
    public static Circle GetCircle()
    {
        double[] input = Console.ReadLine().Split().Select(double.Parse).ToArray();
        Point point = new Point() { x = input[0], y = input[1] };
        Circle circle = new Circle() { point = point, r = input[2] };
        return circle;

    }

    class Point
    {
        public double x { get; set; }
        public double y { get; set; }

        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public double GetDistance(Point point1, Point point2)
        {
            double distance = Math.Sqrt(Math.Pow(point2.x - point1.x, 2) + Math.Pow(point2.y - point1.y, 2));
            return distance;
        }
    }

    class Circle
    {
        public Point point { get; set; }
        public double r { get; set; }
    }
}
