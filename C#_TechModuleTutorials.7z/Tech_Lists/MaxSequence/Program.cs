﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MaxSequence
{
    class Program
    {
        static void Main(string[] args)
        {
            var numbers = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToList();
            int bestStart = 0;
            int bestLength = 0;
            int start = 0;
            int length = 1;

            for (int i = 1; i < numbers.Count; i++)
            {
                if (numbers[i - 1] == numbers[i])
                {
                    start = i - length;
                }
                else
                {                   
                    length = 0;
                    start = 0;
                }
                if (length > bestLength)
                {
                    bestLength = length;
                    bestStart = start;
                }
                length += 1;

            }
            //Console.WriteLine($"{bestStart} {bestLength}");
            for (int i = bestStart; i <= bestLength + bestStart; i++)
            {
                Console.Write(numbers[i] + " ");
            }
            Console.WriteLine();

        }
    }
}
