﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ChangeList
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int>  numbers = Console.ReadLine()
                .Split(" ",StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToList();


            string[] input;

            while (true)
            {
                input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (input[0] == "Odd" || input[0] == "Even")
                {
                    break;
                }
                if (input[0] == "Delete")
                {
                    DeleteList(numbers,input);
                }
                if (input[0] == "Insert")
                {
                    InsertElement(numbers, input);
                }

            }
            if (input[0] == "Odd")
            {
                for (int i = 0; i < numbers.Count; i++)
                {
                    if (numbers[i] % 2 != 0)
                    {
                        Console.Write(numbers[i] + " ");
                    }
                }
                Console.WriteLine();
            }
            else
            {
                for (int i = 0; i < numbers.Count; i ++)
                {
                    if (numbers[i] % 2 == 0)
                    {
                        Console.Write(numbers[i] + " ");
                    }
                }
                Console.WriteLine();
            }

        }

        static List<int> DeleteList(List<int> list,string[] array)
        {
            int number = int.Parse(array[1]);

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] == number)
                {
                    list.Remove(number);
                    i--;    // list change his index
                }
            }
            return list;
        }

        static List<int> InsertElement(List<int> list, string[] array)
        {
            int element = int.Parse(array[1]);
            int position = int.Parse(array[2]);

            if (list.Count < position)
            {
                list.Add(element);
            }
            else
            {
                list.Insert(position,element);
            }
            return list;
        }
    }
}
