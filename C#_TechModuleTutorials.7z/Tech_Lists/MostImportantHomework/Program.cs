﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MostImportantHomework
{
    class Program
    {
        static void Main(string[] args)
        {
            List<long> numbers = Console.ReadLine().Split(' ').Select(long.Parse).ToList();
            string command = Console.ReadLine();

            while (command != "print")
            {
                string[] input = command.Split(' ');
                if (input[0] == "add")
                {
                    int index = int.Parse(input[1]);
                    long element = long.Parse(input[2]);
                    numbers.Insert(index, element);
                }
                else if (input[0] == "addMany")
                {
                    int index2 = int.Parse(input[1]);
                    List<long> elementsToAdd = input.Skip(2).Select(long.Parse).ToList();
                    numbers.InsertRange(index2, elementsToAdd);
                }
                else if (input[0] == "contains")
                {
                    long element2 = long.Parse(input[1]);
                    Console.WriteLine(numbers.IndexOf(element2));

                }
                else if (input[0] == "remove")
                {
                    int index3 = int.Parse(input[1]);
                    numbers.RemoveAt(index3);
                }
                else if (input[0] == "shift")
                {
                    int positions = int.Parse(input[1]);
                    for (int i = 0; i < positions; i++)
                    {
                        long lastElement = numbers[0];
                        for (int j = 0; j < numbers.Count - 1; j++)
                        {
                            numbers[j] = numbers[j + 1];
                        }
                        numbers[numbers.Count - 1] = lastElement;
                    }
                }
                else if  (input[0] == "sumPairs")
                {
                    List<long> newList = new List<long>();
                    for (int i = 0; i < numbers.Count - 1; i += 2)
                    {
                        newList.Add(numbers[i] + numbers[i + 1]);
                    }
                    if (numbers.Count % 2 == 1)
                    {
                        newList.Add(numbers[numbers.Count - 1]);
                    }
                    numbers = newList;
                }
                command = Console.ReadLine();
            }
            Console.WriteLine("[" + string.Join(", ", numbers) + "]");
        }




        static List<int> Add(List<int> List, string[] array)
        {
            int index = int.Parse(array[1]);
            int element = int.Parse(array[2]);
            if (index > List.Count)
            {
                index = List.Count;
            }
            List.Insert(index, element);

            return List;
        }
        static List<int> AddMany(List<int> List, string[] array)
        {
            int index = int.Parse(array[1]);
            
            for (int i = 2; i < array.Length; i++)
            {
                int element = int.Parse(array[i]);
                if (index > List.Count)
                {
                    index = List.Count;
                }
                List.Insert(index, element);
                index++;
            }
            return List;
        }
        static List<int> Contains(List<int> List, string[] array)
        {
            int element = int.Parse(array[1]);
            int ocurance = 0;
            for (int i = 0; i < List.Count; i++)
            {
                if (element == List[i])
                {
                    Console.WriteLine($"{i}");
                    ocurance = 1;
                    break;
                }
            }
            if (ocurance == 0)
            {
                Console.WriteLine("-1");
            }
            return List;
        }

        static List<int> Remove(List<int> List, string[] array)
        {
            int index = int.Parse(array[1]);
            if (index > List.Count)
            {
                index = List.Count;
            }
            List.Remove(index);

            return List;
        }

        static List<int> Shift(List<int> List)
        {
            int[] array = new int[List.Count];
            array[array.Length - 1] = List[0];

            for (int i = array.Length - 2; i >= 0; i--)
            {
                array[i] = List[i + 1];
            }
            for (int i = 0; i < array.Length; i++)
            {
                List[i] = array[i];
            }

            return List;
        }
        static List<int> SumPairs(List<int> List)
        {
            List<int> newList = new List<int>();
            for (int i = 0; i < List.Count - 1; i += 2)
            {
                newList.Add(List[i] + List[i + 1]);
            }
            if (List.Count % 2 == 1)
            {
                newList.Add(List[List.Count - 1]);
            }
             return List = newList;
        }


    }
}
