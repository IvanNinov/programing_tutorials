﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SumReversed
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> numbers = Console.ReadLine().Split(' ').ToList();
            string container = "";

            long sum = 0;
            for (int i = 0; i < numbers.Count; i++)
            {
                string command = numbers[i];
                container = ReverseString(command);
                sum += long.Parse(container);

            }
            Console.WriteLine($"{sum}");
        }
        static string ReverseString(string arr)
        {
            string result = "";

            for (int i = 0; i < arr.Length; i++)
            {
                result += arr[arr.Length - i - 1];
            }
            return result;
        }
    }

    
}
