﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BombNumbers
{

    class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = Console.ReadLine().Split(" ").Select(int.Parse).ToList();
            string[] commands = Console.ReadLine().Split(" ");

            int bomb = int.Parse(commands[0]);
            int power = int.Parse(commands[1]);

            for (int j = 0; j < numbers.Count; j++)
            {
                if (numbers[j] == bomb)
                {
                    int left = Math.Max(j - power, 0);
                    int right = Math.Min(j + power , numbers.Count - 1 );
                    int length = right - left + 1; // 1 for the bomb
                    numbers.RemoveRange(left,length);
                    j = 0;
                }
            }            

            Console.WriteLine(numbers.Sum());

        }
        
    }
}
