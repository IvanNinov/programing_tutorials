﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FindNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToList();
            string[] input = Console.ReadLine()
                .Split(" ",StringSplitOptions.RemoveEmptyEntries)
                .ToArray();
            List<int> manipolate = TakeList(numbers,input);
            List<int> remainingList = DeleteFromList(manipolate,input);

            if (remainingList.Contains(int.Parse(input[2])))
            {
                Console.WriteLine("YES!");
            }
            else
            {
                Console.WriteLine("NO!");
            }
        }

        static List<int> TakeList(List<int> List, string[] array)
        {
            int numberOfElements = int.Parse(array[0]);
            List<int> NewList = new List<int>();
            for (int i = 0; i < numberOfElements; i++)
            {
                NewList.Add(List[i]);
            }
            return NewList;

        }
        static List<int> DeleteFromList(List<int> List, string[] array)
        {
            int numberOfElements = int.Parse(array[1]);
            List<int> NewList = new List<int>();
            for (int i = 0; i < List.Count; i++)
            {
                NewList.Add(List[i]);
            }
            for (int i = 0; i < numberOfElements; i++)
            {
                NewList.RemoveAt(0);
                
            }
            return NewList;
        }
        
    }
}
