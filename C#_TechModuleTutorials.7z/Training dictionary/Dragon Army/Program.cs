﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Dragon_Army
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Dictionary<string, List<long>>> Dragons = new Dictionary<string, Dictionary<string, List<long>>>();

            int n = int.Parse(Console.ReadLine());

            while (n-- > 0)
            {
                string[] tokens = Console.ReadLine().Split();
                string type = tokens[0];
                string name = tokens[1];
                long damage  = tokens[2].Equals("null") ? 45 : long.Parse(tokens[2]);
                long health = tokens[3].Equals("null") ? 250 : long.Parse(tokens[3]);
                long armor = tokens[4].Equals("null") ? 10 : long.Parse(tokens[4]);

                List<long> stats = new List<long>();
                stats.Add(damage);
                stats.Add(health);
                stats.Add(armor);
                if (!Dragons.ContainsKey(type))
                {
                    Dragons.Add(type,new Dictionary<string, List<long>>());                    
                }
                if (!Dragons[type].ContainsKey(name))
                {
                    Dragons[type].Add(name,new List<long>());
                }
                //Dragons[type][name].Add(damage);
                //Dragons[type][name].Add(health);
                //Dragons[type][name].Add(armor);
                Dragons[type][name] = stats;

            }
            Console.WriteLine();
            foreach (var dragon in Dragons)
            {
                double sumD = 0;
                double sumH = 0;
                double sumA = 0;
                Dictionary<string, List<long>> namesWithStats = Dragons[dragon.Key];


                foreach (var value in namesWithStats.Values)
                {
                    //Console.WriteLine(namesWithStats[value.Key][0]);
                    //Console.WriteLine(value[0]);
                    sumD += value[0];
                    sumH += value[1];
                    sumA += value[2];
                }
                Console.WriteLine($"{dragon.Key}::({sumD / namesWithStats.Count:F2}" +
                    $"/{sumH / namesWithStats.Count:F2}" +
                    $"/{sumA / namesWithStats.Count:F2})");
                foreach (var name in namesWithStats.OrderBy(x => x.Key).ToDictionary(x => x.Key, y => y.Value))
                {
                    Console.WriteLine($"-{name.Key} -> " +
                        $"damage: {name.Value[0]}, health: {name.Value[1]}, armor: {name.Value[2]}");
                }
            }




        }
    }
}
