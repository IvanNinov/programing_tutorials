﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace one
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, List<int>> firstDict = new Dictionary<string, List<int>>();
            List<int> list = new List<int>();
            //int[] text = Console.ReadLine().Split().Select(int.Parse).ToArray();
            string[] txt = Console.ReadLine().ToLower().Split().ToArray();
            Random rnd = new Random();


            foreach (var word in txt)
            {
                for (int i = 0; i < txt.Length; i++)
                {
                    list.Add(rnd.Next(1, 25));
                }
                if (!firstDict.ContainsKey(word))
                {
                    firstDict.Add(word,new List<int>());
                    firstDict[word] = list;

                }
               // firstDict[word] = list;

            }

            Console.WriteLine();

            //foreach (var item in firstDict)    // pair (key,value)  
            //{
            //    Console.WriteLine($"{item.Key} , {item.Value}");
            //}
        }
    }
}
