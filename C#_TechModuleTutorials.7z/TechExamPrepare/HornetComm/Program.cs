﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;


namespace HornetComm
{
    class Program
    {
        static void Main(string[] args)
        {
            Regex messagePattern = new Regex(@"^([0-9]+) <-> ([0-9A-Za-z]+)$");
            Regex broadcastPattern = new Regex(@"^([^0-9]+) <-> ([0-9A-Za-z]+)$");

            List<string[]> Message = new List<string[]>();
            List<string[]> Broadcast = new List<string[]>();


            string input = Console.ReadLine();
            while (input != "Hornet is Green")
            {
                Match matchMessage = messagePattern.Match(input);
                Match matchBroadcast = broadcastPattern.Match(input);

                if (matchMessage.Success)
                {
                    string recipiensCode = matchMessage.Groups[1].Value;
                    recipiensCode = ReverseString(recipiensCode);
                    string message = matchMessage.Groups[2].Value;
                    string[] code = { recipiensCode, message };
                    string nameSignal = "Messages";
                    Message.Add(code);
                }
                else if (matchBroadcast.Success)
                {
                    string message = matchBroadcast.Groups[1].Value;
                    string frequency = matchBroadcast.Groups[2].Value;
                    frequency = ChangeLetter(frequency);
                    string[] code  = { frequency, message };
                    Broadcast.Add(code);
                }
                input = Console.ReadLine();
            }
            Console.WriteLine($"Broadcasts: ");
            if (Broadcast.Count == 0)
            {
                Console.WriteLine("None");
            }
            else
            {
                foreach (var br in Broadcast)
                {
                    Console.WriteLine($"{br[0]} -> {br[1]}");
                }
            }           
            Console.WriteLine($"Messages: ");
            if (Message.Count == 0)
            {
                Console.WriteLine("None");
            }
            else
            {
                foreach (var ms in Message)
                {
                    Console.WriteLine($"{ms[0]} -> {ms[1]}");
                }
            }
           

        }

        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
        public static string ChangeLetter(string arr)
        {
            char[] s = arr.ToCharArray();
            for (int i = 0; i < s.Length; i++)
            {
                if (char.IsLower(s[i]) && char.IsLetter(s[i]))
                {
                    s[i] = char.ToUpper(s[i]);
                }
                else if (char.IsUpper(s[i]) && char.IsLetter(s[i]))
                {
                    s[i] = char.ToLower(s[i]);
                }   
            }
            return new string(s);
        }
    }
}
