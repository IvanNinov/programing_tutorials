﻿using System;
using System.Text.RegularExpressions;

namespace Winning_Ticket
{
    class Program
    {
        static void Main(string[] args)
        {
            Regex regex = new Regex(@"(?<part>([\#]{6,9}|[\^]{6,9}|[\@]{6,9}|[\$]{6,9})).*(\k<part>)");
            Regex jackpot = new Regex(@"[\#]{20}|[\^]{20}|[\@]{20}|[\$]{20}");
            Regex partMatch = new Regex(@"([\#]{6,9}|[\^]{6,9}|[\@]{6,9}|[\$]{6,9})");

            string[] input = Console.ReadLine()
                .Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < input.Length; i++)
            {
                input[i] = input[i].Trim();
            }
            foreach (var line in input)
            {
                if (line.Length > 20 || line.Length < 20)
                {
                    Console.WriteLine("invalid ticket");
                    continue;
                }
                string firstHalf = line.Substring(0,10);
                string secondHalf = line.Substring(10, 10);
                Match firstPart = partMatch.Match(firstHalf);
                Match secondPart = partMatch.Match(secondHalf);
                int length = Math.Min(firstPart.Length,secondPart.Length);
                Match Jackpot = jackpot.Match(line);
                Match pattern = regex.Match(line);

                if (Jackpot.Success)
                {
                    Console.WriteLine($"ticket \"{line}\" - 10{line[0]} Jackpot!");
                    continue;
                }
                else if (firstPart.Success && secondPart.Success && 
                    firstPart.Groups[1].Value[0] == secondPart.Groups[1].Value[0])
                {
                      Console.WriteLine($"ticket \"{line}\" - {length}" +
                            $"{firstPart.Groups[1].Value[0]}");
                }
                else
                {
                    Console.WriteLine($"ticket \"{line}\" - no match");
                }

            }
        }
    }
}
//100pts