﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace TseamAccount
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> account = new List<string>();
            account = Console.ReadLine().Split().ToList();
            string input = Console.ReadLine();
            Regex expPattern = new Regex(@"Expansion");
            Regex matchWithout = new Regex(@"^([^\-]+)$");
            Regex contentPattern = new Regex(@"^Expansion ([^\-]+)\-([^\- \n]+)$");
            //^Expansion ([^\-].?[^\-]+)\-(.?[^\-])$
            while (input != "Play!")
            {
                Match matchContent = contentPattern.Match(input);
                string[] splited = input.Split();
                Match containsNoMinus = matchWithout.Match(splited[1]);


                if (splited[0] == "Expansion")
                {
                    foreach (var item in account)
                    {
                        if (matchContent.Groups[1].Value == item)
                        {
                            int count = account.IndexOf(item);
                            account.Insert(count + 1, $"{matchContent.Groups[1].Value}:{matchContent.Groups[2].Value}");
                            break;
                        }
                    }
                }
                else if (splited[0] == "Install")
                {
                    if (!account.Contains(splited[1]) && containsNoMinus.Success)
                    {
                        account.Add(splited[1]);
                    }
                }
                else if (splited[0] == "Update")
                {
                    if (account.Contains(splited[1]))
                    {
                        account.Remove(splited[1]);
                        account.Add(splited[1]);
                    }
                }
                else
                {
                    if (account.Contains(splited[1]))
                    {
                        account.Remove(splited[1]);
                    }
                }   
                input = Console.ReadLine();
            }
            foreach (var item in account)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();

        }
    }
}
