﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace MOBAChallenger
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            Regex pattern = new Regex($@"^(\b[^ ]+\b) -> (\b[^ ]+\b) -> (\b[^ ]+\b)$");
            Regex patternDuel = new Regex(@"^(\b[^ ]+\b) vs (\b[^ ]+\b)$");

            Dictionary<string, Dictionary<string, int>> PlayersPool = new Dictionary<string, Dictionary<string, int>>();
            Dictionary<string, int> NameBySkill = new Dictionary<string, int>();

            while (input != "Season end")
            {
                Match patt = pattern.Match(input);
                Match pattDuel = patternDuel.Match(input);

                if (patt.Success)
                {
                    string name = patt.Groups[1].Value;
                    string position = patt.Groups[2].Value;
                    int skill = int.Parse(patt.Groups[3].Value);


                    if (!PlayersPool.ContainsKey(name))
                    {
                        PlayersPool.Add(name,new Dictionary<string, int>());
                        PlayersPool[name].Add(position,skill);
                        //NameBySkill.Add(name,skill);
                    }
                    else if (!PlayersPool[name].ContainsKey(position))
                    {
                        PlayersPool[name].Add(position, skill);
                        //NameBySkill[name] += skill;
                    }
                    else
                    {
                        if (PlayersPool[name][position] < skill)
                        {
                            PlayersPool[name][position] = skill;
                        }
                    }
                }
                else
                {
                    string nameF = pattDuel.Groups[1].Value;
                    string nameS = pattDuel.Groups[2].Value;
                    if (PlayersPool.ContainsKey(nameF) && PlayersPool.ContainsKey(nameS))
                    {
                        int skillF = 0;
                        int skillS = 0;
                        foreach (var name in PlayersPool[nameF])
                        {

                                skillF += name.Value;
                            
                        }
                        foreach (var name in PlayersPool[nameS])
                        {
                            
                                skillS += name.Value;   
                        }

                        foreach (var position in PlayersPool[nameF])
                        {
                            foreach (var pos in PlayersPool[nameS])
                            {
                                if (position.Key == pos.Key)
                                {
                                    if (skillF > skillS && PlayersPool.ContainsKey(nameS))
                                    {
                                        PlayersPool.Remove(nameS);
                                    }
                                    else if (skillF < skillS && PlayersPool.ContainsKey(nameF))
                                    {
                                        PlayersPool.Remove(nameF);
                                    }
                                }
                            }
                        }
                    }

                }          
                input = Console.ReadLine();
            }
            foreach (var name in PlayersPool)
            {
                if (!NameBySkill.ContainsKey(name.Key))
                {
                    NameBySkill.Add(name.Key, 0);
                }
                foreach (var pos in PlayersPool[name.Key])
                {
                    NameBySkill[name.Key] += pos.Value;
                }
            }

            foreach (var name in NameBySkill.OrderByDescending(x => x.Value).ThenBy(x => x.Key))
            {
                Console.WriteLine($"{name.Key}: {name.Value} skill");
                foreach (var pos in PlayersPool[name.Key].OrderByDescending(x => x.Value))
                {
                    Console.WriteLine($"- {pos.Key} <::> {pos.Value}");
                }
            }
        }
    }
}
//80pts