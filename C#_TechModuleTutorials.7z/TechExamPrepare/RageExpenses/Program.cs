﻿using System;

namespace RageExpenses
{
    class Program
    {
        static void Main(string[] args)
        {
            int lostGamesCount = int.Parse(Console.ReadLine());
            double headsetPrice = double.Parse(Console.ReadLine());
            double mousePrice = double.Parse(Console.ReadLine());
            double keyboardPrice = double.Parse(Console.ReadLine());
            double displayPrice = double.Parse(Console.ReadLine());

            int headsetCount = 0;
            int mouseCount = 0;
            int keyboardCount = 0;
            int displayCount = 0;

            for (int i = 1; i <= lostGamesCount; i++)
            {
                if (i % 2 == 0)
                {
                    headsetCount++;
                }
                if (i % 3 == 0)
                {
                    mouseCount++;
                }
                if (i % 6 == 0)
                {
                    keyboardCount++;
                    if (keyboardCount % 2 == 0 && keyboardCount != 0)
                    {
                        displayCount++;
                    }
                }

            }
            double expenses = (double)(headsetPrice*headsetCount)+
                (double)(mousePrice*mouseCount)+(double)(keyboardPrice*keyboardCount)+(double)(displayPrice*displayCount);

            Console.WriteLine($"Rage expenses: {expenses:F2} lv.");

        }
    }
}
