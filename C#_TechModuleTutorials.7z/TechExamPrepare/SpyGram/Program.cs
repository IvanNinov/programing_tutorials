﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SpyGram
{
    class Program
    {
        static void Main(string[] args)
        {
            Regex messageCodePattern = new Regex(@"^TO: ([A-Z]+?); MESSAGE: [\w \S]+?;$");
            string code = Console.ReadLine();
            string input = Console.ReadLine();
            Match collectMessageMatch;

            List<string> validMessages = new List<string>();
            List<char> changedMessages = new List<char>();
            Dictionary<string, List<string>> nameText = new Dictionary<string, List<string>>();


            while (input != "END")
            {
                collectMessageMatch = messageCodePattern.Match(input);
                if (collectMessageMatch.Success)
                {
                    string validMessage = collectMessageMatch.Value.ToString();
                    if (!nameText.ContainsKey(collectMessageMatch.Groups[1].Value.ToString()))
                    {
                        nameText.Add(collectMessageMatch.Groups[1].Value.ToString(), new List<string>());
                        nameText[collectMessageMatch.Groups[1].Value.ToString()].Add(validMessage);
                    }
                    else
                    {
                        nameText[collectMessageMatch.Groups[1].Value.ToString()].Add(validMessage);
                    }                   
                }
                else
                {
                    input = Console.ReadLine();
                    continue;
                }
                input = Console.ReadLine();
            }         
            foreach (var name in nameText.OrderBy(x => x.Key))
            {
                foreach (string item in nameText[name.Key])
                {
                    string result = Change(item, code);
                    Console.WriteLine(result);
                }       
            }
        }


        static string Change(string validMessage,string number)
        {
            //82738
            //TO: ARCHER; MESSAGE: affirmative;
            //\QA#IZEOHZC"TH[[CNHB(cmiqzohwq~gB
            StringBuilder changed = new StringBuilder();
            for (int i = 0; i < validMessage.Length; i++)
            {
                int asciiCode = validMessage[i] + int.Parse(number[i % number.Length].ToString());
                changed.Append((char)asciiCode);
            }
            return changed.ToString();
        }
    }
}
