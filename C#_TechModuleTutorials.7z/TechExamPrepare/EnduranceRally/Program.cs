﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EnduranceRally
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> drivers = Console.ReadLine()
                .Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
                .ToList();
            double[] zones = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
            int[] index = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            for (int i = 0; i < drivers.Count; i++)
            {
                double startFuel = (double)drivers[i][0];
                int zoneCount = 0;
                bool unfinished = false;
                for (int k = 0; k < zones.Length; k++)
                {
                    bool foundIndex = false;
                    for (int j = 0; j < index.Length; j++)
                    {
                        if (k == index[j])
                        {
                            startFuel += zones[k];
                            foundIndex = true;
                            break;
                        }
                    }
                    if (foundIndex == false)
                    {
                        startFuel -= zones[k];
                    }
                    if (startFuel <= 0)
                    {
                        unfinished = true;
                        break;
                    }
                    zoneCount++;
                }
                if (startFuel > 0)
                {
                    Console.WriteLine($"{drivers[i]} - fuel left {startFuel:F2}");
                }
                else if (unfinished)
                {
                    Console.WriteLine($"{drivers[i]} - reached {zoneCount}");
                }
            }
                

            

        }
    }
}
