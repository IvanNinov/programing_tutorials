﻿using System;
using System.Numerics;

namespace SinoTheWalker
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            DateTime dt;
            while (!DateTime.TryParseExact(line, "HH:mm:ss", null, System.Globalization.DateTimeStyles.None, out dt))
            {
                Console.WriteLine("Invalid date, please retry");
                line = Console.ReadLine();
            }

            int stepsCount = int.Parse(Console.ReadLine())%86400;
            int timeInSec = int.Parse(Console.ReadLine())%86400;
            long time = stepsCount * timeInSec;
            dt = dt.AddSeconds(time);
            Console.WriteLine($"Time Arrival: {dt.TimeOfDay}");
            //int min = timeInSec / 60;
            //int hh = min / 60;
            //int remeiningSec = timeInSec % 60;

        }
    }
}
