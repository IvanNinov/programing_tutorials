﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MemoryView
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder buildedInput = new StringBuilder();
            Regex pattern = new Regex(@"(?>32656 19759 32763 )0 (\d) 0 ");
            List<int> count = new List<int>();
            List<string> word = new List<string>();
            string Text = Console.ReadLine();
            while (Text != "Visual Studio crash")
            {
                buildedInput.Append(Text + " ");
                Text = Console.ReadLine();
            }

            string[] substrings = Regex.Split(buildedInput.ToString(), @"(?>32656 19759 32763 )0 (\d) 0 ");

            foreach (var item in substrings.Where(i => i.Length == 1))
            {
                count.Add(int.Parse(item));
            }
            foreach (var item in substrings.Where(i => i.Length != 1 ))
            {
                word.Add(item);
            }
            if (word.Count > 1 )
            {
                word.RemoveAt(0);
            }

            for (int i = 0; i < count.Count; i++)
            {
                List<int> print = word[i].Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToList();
                for (int k = 0; k < count[i]; k++)
                {
                    Console.Write((char)print[k]);
                }
                Console.WriteLine();

            }
 
            //90 points
        }
    }
}
