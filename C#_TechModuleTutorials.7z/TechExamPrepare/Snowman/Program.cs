﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Snowman
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> snowmens = new List<int>();
            snowmens=Console.ReadLine().Split().Select(int.Parse).ToList();
            while (snowmens.Count > 1)
            {
                for (int i = 0; i < snowmens.Count; i++)
                {
                    int attacker = i;
                    int target = snowmens[i] % snowmens.Count;
                    int diff = Math.Abs(attacker-target);
                    var finished = new List<int>();
                    if (snowmens.Count(x => x != -1) == 1)
                    {
                        break;
                    }
                    if (snowmens[i] == -1 )
                    {
                        continue;
                    }
                    if (attacker == target)
                    {
                        //suiside
                        snowmens[attacker] = -1;
                        finished.Add(attacker);
                        Console.WriteLine($"{ attacker}performed harakiri");
                    }
                    else if (diff %2 != 0)
                    {
                        //target wins
                        snowmens[attacker] = -1;
                        finished.Add(attacker);
                        Console.WriteLine($"{attacker} x {target} -> {target} wins");
                    }
                    else
                    {
                        //attacker wins
                        snowmens[target] = -1;
                        finished.Add(target);                 
                        Console.WriteLine($"{attacker} x {target} -> {attacker} wins");

                    }

                    snowmens = snowmens.Where(x => x != -1).ToList();

                }
            }

        }
    }
}
