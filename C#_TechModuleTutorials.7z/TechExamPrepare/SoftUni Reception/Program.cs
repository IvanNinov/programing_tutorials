﻿using System;

namespace SoftUni_Reception
{
    class Program
    {
        static void Main(string[] args)
        {
            int first = int.Parse(Console.ReadLine());
            int second = int.Parse(Console.ReadLine());
            int third = int.Parse(Console.ReadLine());
            int students = int.Parse(Console.ReadLine());

            int efficincy= first + second + third;
            int hours = 0;
            int count = 1;
            int cons = 0;
            while (true)
            {
                if (students <= 0)
                {
                    break;
                }
                else if (count % 4 == 0 )

                {
                    cons++; 
                    count++;
                    continue;
                }
                else
                {
                    students = students - efficincy;
                    hours++;
                }
                count++;
            }

 
            
            Console.WriteLine($"Time needed: {hours + cons}h.");



        }
    }
}
