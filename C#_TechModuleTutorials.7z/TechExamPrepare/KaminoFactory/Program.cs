﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace KaminoFactory
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string line = Console.ReadLine();
            string[] numbers = new string[n];        
            int bestLen = -1;
            int bestSum = 0;
            int currSampleIndex = 0;
            int startIndex = -1;
            int bestSampleIndex = 0;


            while (line != "Clone them!")
            {
                int cntLen = 0;
                int cntBestLen = 0;
                int cntEndIndex = 0;
                string[] currentDna = line.Split('!', StringSplitOptions.RemoveEmptyEntries);

                for (int i = 0; i < currentDna.Length; i++)
                {
                    if (currentDna[i] == "1")
                    {
                        cntLen++;
                        if (cntLen > cntBestLen)
                        {
                            cntBestLen = cntLen;
                            cntEndIndex = i;
                        }
                    }
                    else
                    {
                        cntLen = 0;
                    }
                }
                int currStartIndex = cntEndIndex - cntBestLen + 1;

                bool isCurrBetter = false;
                int currDnaSum = currentDna.Select(int.Parse).Sum();

                if (cntBestLen > bestLen)
                {
                    isCurrBetter = true;
                }
                else if (cntBestLen == bestLen)
                {
                    if (currStartIndex < startIndex)
                    {
                        isCurrBetter = true;
                    }
                    else if (currStartIndex == startIndex)
                    {
                        if (currDnaSum > bestSum)
                        {
                            isCurrBetter = true;
                        }                      
                    }
                }
                currSampleIndex++;
                if (isCurrBetter)
                {
                    numbers = currentDna;
                    bestLen = cntBestLen;
                    startIndex = currStartIndex;
                    bestSum = currDnaSum;
                    bestSampleIndex = currSampleIndex;
                }



                line = Console.ReadLine();
            }
            Console.WriteLine($"Best DNA sample {bestSampleIndex} with sum: {bestSum}.");
            Console.WriteLine(string.Join(' ', numbers));
        }
        
        
    }
}
