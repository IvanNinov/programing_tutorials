﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace StarEnigma
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Regex patternMessage = 
                new Regex(@"@([A-Za-z]+)[^\-\@!:>]*:([0-9]+)[^\-\@!:>]*!([AD])![^\-\@!:>]*\-\>([0-9]+)");
            List<string> Attacked = new List<string>();
            List<string> Destroyed = new List<string>();


            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                int count = 0;
                foreach (char c in line.ToLower())
                {
                    if (c == 's' || c == 't' || c == 'a' || c == 'r' )
                    {
                        count++;
                    }
                }
                StringBuilder newLine = new StringBuilder();
                for (int charInLine = 0; charInLine < line.Length; charInLine++)
                {
                    int chars = (char)line[charInLine];
                    chars = chars - count;
                    newLine.Append((char)chars);
                }
                Match match = patternMessage.Match(newLine.ToString());
                if (match.Success)
                {
                    if (match.Groups[3].Value == "A")
                    {
                        Attacked.Add(match.Groups[1].Value);
                    }
                    else if (match.Groups[3].Value == "D")
                    {
                        Destroyed.Add(match.Groups[1].Value);
                    }
                }
            }
            Console.WriteLine($"Attacked planets: {Attacked.Count}");
            foreach (var item in Attacked.OrderBy(x => x))
            {
                Console.WriteLine($"-> {item}");
            }
            Console.WriteLine($"Destroyed planets: {Destroyed.Count}");
            foreach (var item in Destroyed.OrderBy(x => x))
            {
                Console.WriteLine($"-> {item}");
            }
        }
    }
}
