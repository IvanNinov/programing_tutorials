﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;

namespace Karaoke
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> participants = Console.ReadLine().Split(" ,".ToCharArray(),StringSplitOptions.RemoveEmptyEntries).ToList();
            string[] songs = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            Dictionary<string, List<string>> Awards = new Dictionary<string, List<string>>();
            Dictionary<string, Dictionary<string,List<string>>> printAwards = new Dictionary<string, Dictionary<string, List<string>>>();
            string input = Console.ReadLine();
            Regex pat = new Regex($@"(.+), (.+), (.+)");

            while (input != "dawn")
            {
                string[] token = input.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
                string name = token[0];
                string song = token[1];
                string award = token[2];
                Match match = pat.Match(input);
                if (!match.Success)
                {
                    input = Console.ReadLine();
                    continue;
                }
                if (participants.Contains(name) && songs.Contains(song))
                {
                    if (!printAwards.ContainsKey(name))
                    {
                        printAwards.Add(name,new Dictionary<string, List<string>>());
                       
                    }
                    if (!printAwards[name].ContainsKey(song))
                    {
                        printAwards[name].Add(song, new List<string>());
                    }
                    if (!printAwards[name][song].Contains(award))
                    {
                        printAwards[name][song].Add(award);
                        printAwards[name][song].Sort();
                    }
                }
                input = Console.ReadLine();
            }

            foreach (var name in printAwards.Keys)
            {
                foreach (var song in printAwards[name])
                {
                    if (!Awards.ContainsKey(name))
                    {
                        Awards.Add(name, new List<string>());
                    }
                    Awards[name] = song.Value;
                    Awards[name].Sort();
                } 
            }
            if (printAwards.Count == 0)
            {
                Console.WriteLine($"No awards");
            }
            else
            {
                foreach (var name in Awards.OrderByDescending(x=> x.Value.Count).ThenBy(x => x.Key))
                {
                    Console.WriteLine($"{name.Key}: {name.Value.Count} awards");
                    foreach (var item in name.Value)
                    {
                        Console.WriteLine($"--{item}");
                    }
                }
            }

        }
    }
}
//80pts