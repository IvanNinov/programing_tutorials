﻿using System;

namespace Padawan_Equipment
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal money = decimal.Parse(Console.ReadLine());
            int students = int.Parse(Console.ReadLine());
            decimal lightsabersPrice = decimal.Parse(Console.ReadLine());
            decimal robesPrice = decimal.Parse(Console.ReadLine());
            decimal beltsPrice = decimal.Parse(Console.ReadLine());
            //sabresPrice*(studentsCount + 10%) + robesPrice * (studentsCount) + beltsPrice*(studentsCount-freeBelts)
            int studentPer =(int)Math.Ceiling(students + (0.1*students));
            decimal result = (lightsabersPrice * studentPer) + (robesPrice * students) + beltsPrice*(students - (students/6) );
            if (result <= money)
            {
                Console.WriteLine($"The money is enough - it would cost {result:F2}lv.");
                return;
            }
            Console.WriteLine($"Ivan Cho will need {(result - money):F2}lv more.");
        }
    }
}
