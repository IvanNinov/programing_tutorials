﻿using System;
using System.Text.RegularExpressions;

namespace SoftUni_Bar_Income
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            //Regex regex = new Regex(@"^%([A-Z][a-z]+)%[^\|\$\%\.]*<([A-Za-z]+)>[^\|\$\%\.]*\|([0-9]+)\|[^\|\$\%\.0-9]*([0-9.]+)\$$");
            Regex regex = new Regex(@"%([A-Z][a-z]+)%[^\|\$\%\.]*<(\w+)>[^\|\$\%\.]*\|([0-9]+)\|[^\|\$\%\.0-9]*([0-9.]+)\$");
            double sum = 0;
            double totalSum = 0;
            while (input != "end of shift")
            {
                Match match = regex.Match(input);
                if (match.Success)
                {
                    string name = match.Groups[1].Value;
                    string product = match.Groups[2].Value;
                    double price = double.Parse(match.Groups[4].Value);
                    int count = int.Parse(match.Groups[3].Value);
                    sum = count * price;
                    totalSum += sum;
                    Console.WriteLine($"{name}: {product} - {sum:F2}");
                }
                input = Console.ReadLine();
            }
            Console.WriteLine($"Total income: {totalSum:F2}");


        }
    }
}
