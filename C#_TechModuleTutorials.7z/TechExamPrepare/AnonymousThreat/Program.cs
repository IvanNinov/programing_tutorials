﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AnonymousThreat
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> input = Console.ReadLine().Split(" ".ToCharArray()).ToList();

            string commands = Console.ReadLine();

            while (commands != "3:1")
            {
                string[] tokens = commands.Split(" ,".ToCharArray());
                string command = tokens[0];

                if (command == "merge")
                {
                    int startIndex = int.Parse(tokens[1]);
                    int endIndex = int.Parse(tokens[2]);

                    if (startIndex < 0 || startIndex > input.Count)
                    {
                        startIndex = 0;
                    }
                    if (endIndex > input.Count - 1 || endIndex < 0)
                    {
                        endIndex = input.Count - 1;
                    }
                    string concat = "";

                    for (int i = startIndex; i <= endIndex ; i++)
                    {
                        concat = concat + input[i];
                    }
                    input.RemoveRange(startIndex, endIndex - startIndex + 1);
                    input.Insert(startIndex, concat);
                    
                }
                else if (command == "divide")
                {
                    int index = int.Parse(tokens[1]);
                    int partitions = int.Parse(tokens[2]);

                    List<string> newWord = new List<string>();
                    string word = input[index];
                    string sub = "";
                    int par = word.Length / partitions;
                    for (int i = 0; i < partitions; i++)
                    {
                        if (i == partitions - 1)
                        {
                            newWord.Add(word.Substring(i * par));
                            break;             
                        }
                        newWord.Add(word.Substring(i * par,par));
                    }
                    input.RemoveAt(index);
                    input.InsertRange(index,newWord);
                    Console.WriteLine();

                }
                commands = Console.ReadLine();
            }
            Console.WriteLine(string.Join(" ",input));
        }
    }
}
