﻿using System;

namespace Hornet_Wings
{
    class Program
    {
        static void Main(string[] args)
        {
            int wingFlaps = int.Parse(Console.ReadLine());
            double distance = double.Parse(Console.ReadLine());
            int endurance = int.Parse(Console.ReadLine());

            double distPerFlaps = (wingFlaps / 1000) * distance;

            int flapsSec = wingFlaps / 100;
            int resSec = (wingFlaps / endurance) * 5;

            Console.WriteLine($"{distPerFlaps:f2} m.");
            Console.WriteLine($"{resSec + flapsSec} s.");



        }
    }
}
