﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftUni_Exam_Results
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Dictionary<string, int>> Participant = new Dictionary<string, Dictionary<string, int>>();
            Dictionary<string, int> NameSubmission = new Dictionary<string, int>();
            Dictionary<string, List<string>> lang = new Dictionary<string, List<string>>();
            Dictionary<string, int> submissions = new Dictionary<string, int>();


            string input = Console.ReadLine();
            while (input != "exam finished")
            {
                string[] tokens = input.Split("-",StringSplitOptions.RemoveEmptyEntries);
                if (tokens[1] != "banned")
                {
                    string username = tokens[0];
                    string language = tokens[1];
                    int points = int.Parse(tokens[2]);

                    if (!Participant.ContainsKey(username))
                    {
                        Participant.Add(username, new Dictionary<string, int>());
                        lang.Add(username, new List<string>());
                        if (!submissions.ContainsKey(language))
                        {
                            submissions.Add(language,1);
                        }
                        else
                        {
                            submissions[language]++;
                        }
                        if (!lang[username].Contains(language))
                        {
                            lang[username].Add(language);

                        }
                        if (!Participant[username].ContainsKey(language))
                        {
                            Participant[username].Add(language, 0);
                            Participant[username][language] = points;     
                        }
                        else if (Participant[username].ContainsKey(language))
                        {
                            Participant[username][language] = points;
                        }
                    }
                    else if (!Participant[username].ContainsKey(language))
                    {
                        lang[username].Add(language);
                        Participant[username].Add(language, 0);
                        Participant[username][language] = points;

                        if (!submissions.ContainsKey(language))
                        {
                            submissions.Add(language, 1);
                        }
                        else
                        {
                            submissions[language]++;
                        }

                    }
                    else if (Participant[username].ContainsKey(language))
                    {
                        Participant[username][language] = points;
                    }
                    if (!lang[username].Contains(language))
                    {
                        lang[username].Add(language);
                    }

                }
                else if (tokens[1] == "banned")
                {
                    string username = tokens[0];
                    if (Participant.ContainsKey(username))
                    {
                        Participant.Remove(username);
                    }

                }
                input = Console.ReadLine();
            }
            foreach (var item in Participant.Values)
            {
                foreach (var t in item.Keys)
                {
                    if (!submissions.ContainsKey(t))
                    {
                        submissions.Add(t,1);
                    }
                    else
                    {
                        submissions[t]++;
                    }
                }
            }

            Console.WriteLine("Results:");
            foreach (var person in Participant)
            {
                foreach (var item in person.Value)
                {
                    Console.WriteLine($"{person.Key} | {item.Value}");
                }
            }

            Console.WriteLine("Submissions:");
            

        }
    }
}
