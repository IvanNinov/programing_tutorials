﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace ForceBook
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> ForceUsers = new Dictionary<string, string>();
            Dictionary<string, List<string>> UsersForce = new Dictionary<string, List<string>>();


            Regex patternCheck = new Regex(@"^(.+) (\|) (.+)$");
            Regex patternJoin = new Regex(@"^(.+) (\->) (.+)$");

            string input = Console.ReadLine();

            while (input != "Lumpawaroo")
            {
                Match check = patternCheck.Match(input);
                Match join = patternJoin.Match(input);

                string nameCheck = check.Groups[3].Value;
                string forceCheck = check.Groups[1].Value;
                string nameJoin = join.Groups[1].Value;
                string forceJoin = join.Groups[3].Value;
                string signCheck = check.Groups[2].Value;
                string signJoin = join.Groups[2].Value;


                if (check.Success)
                {
                    if (signCheck == "|")
                    {
                        if (!ForceUsers.ContainsKey(nameCheck))
                        {
                            ForceUsers.Add(nameCheck, forceCheck);
                        }
                    }
                }
                else if (join.Success)
                {
                    if (signJoin == "->")
                    {
                        if (!ForceUsers.ContainsKey(nameJoin))
                        {
                            ForceUsers.Add(nameJoin, forceJoin);
                            Console.WriteLine($"{nameJoin} joins the {forceJoin} side!");
                        }
                        else
                        {
                            ForceUsers.Remove(nameJoin);
                            ForceUsers.Add(nameJoin, forceJoin);
                            Console.WriteLine($"{nameJoin} joins the {forceJoin} side!");
                        }
                    }
                }
                input = Console.ReadLine();
            }
            foreach (var user in ForceUsers)
            {
                if (!UsersForce.ContainsKey(user.Value))
                {
                    UsersForce.Add(user.Value, new List<string>());
                }
                UsersForce[user.Value].Add(user.Key);
            }
            foreach (var keyValue in UsersForce.OrderByDescending(x => x.Value.Count()).ThenBy(x => x.Key))
            {
                Console.WriteLine($"Side: {keyValue.Key}, Members: {keyValue.Value.Count}");
                foreach (var Value in UsersForce[keyValue.Key].OrderBy(x => x))
                {
                    Console.WriteLine($"! {Value}");
                }
            }
        }
    }
}
