﻿using System;

namespace SplinterTrip
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal tripDistance = decimal.Parse(Console.ReadLine());
            decimal fuelTankCapacity = decimal.Parse(Console.ReadLine());
            decimal milesSpentInHeavyWinds = decimal.Parse(Console.ReadLine());


            decimal milesInNoneWinds = tripDistance - milesSpentInHeavyWinds;
            decimal noneHeavyConsumption = milesInNoneWinds * 25;
            decimal heavyWindsConsumption = milesSpentInHeavyWinds * (25 * 1.5m);
            decimal FuelConsumption = noneHeavyConsumption + heavyWindsConsumption;

            decimal tollerance = FuelConsumption * 0.05m;

            decimal TotalFuel = FuelConsumption + tollerance;

            decimal remainingFuel = Math.Abs(fuelTankCapacity - TotalFuel);
            if (fuelTankCapacity >= TotalFuel)
            {
                Console.WriteLine($"Fuel needed: {TotalFuel:F2}L");
                Console.WriteLine($"Enough with {remainingFuel:F2}L to spare!");
            }
            else
            {
                Console.WriteLine($"Fuel needed: {TotalFuel:F2}L");
                Console.WriteLine($"We need {remainingFuel:F2}L more fuel.");
            }
            

        }
    }
}
