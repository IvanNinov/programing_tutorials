﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace HornetArmada
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Dictionary<string, long> legioNameActivity = new Dictionary<string, long>();
            Dictionary<string, Dictionary<string, long>> legioNameSoldiers = new Dictionary<string, Dictionary<string, long>>();
            Dictionary<string, long> print = new Dictionary<string, long>();
            
            for (int i = 0; i < n; i++)
            {
                string input = Console.ReadLine();
                string[] tokens = input.Split(" :=->"
                    .ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

                long lastActivity = long.Parse(tokens[0]);
                string legionName = tokens[1];
                string soldierType = tokens[2];
                long soldierCount = long.Parse(tokens[3]);

                if (!legioNameActivity.ContainsKey(legionName) && !legioNameSoldiers.ContainsKey(legionName))
                {
                    legioNameActivity.Add(legionName, 0); 
                    legioNameSoldiers.Add(legionName,new Dictionary<string, long>());
                    legioNameActivity[legionName] = lastActivity;
                    if (!legioNameSoldiers[legionName].ContainsKey(soldierType))
                    {
                        legioNameSoldiers[legionName].Add(soldierType, 0);
                        legioNameSoldiers[legionName][soldierType] = soldierCount;
                    }
                }
                else
                {
                    if (legioNameActivity[legionName] < lastActivity)
                    {
                        legioNameActivity[legionName] = lastActivity;
                    }                   
                    if (!legioNameSoldiers[legionName].ContainsKey(soldierType))
                    {
                        legioNameSoldiers[legionName].Add(soldierType, 0);
                        legioNameSoldiers[legionName][soldierType] = soldierCount;
                    }
                    else
                    {
                        legioNameSoldiers[legionName][soldierType] += soldierCount;
                    }
                }
            }
            string[] lastCommand = Console.ReadLine().Split(new string[] { "\\" },StringSplitOptions.RemoveEmptyEntries);

            if (lastCommand.Length > 1)
            {
                int activ = int.Parse(lastCommand[0]);
                string nameType = lastCommand[1];
                
                foreach (var name in legioNameSoldiers)
                {
                    if (legioNameActivity[name.Key] < activ)
                    {
                        foreach (var value in name.Value)
                        {
                            if (value.Key == nameType)
                            {
                                if (!print.ContainsKey(name.Key))
                                {
                                    print.Add(name.Key, value.Value);
                                }
                            }
                        }
                    }

                }
                foreach (var p in print.OrderByDescending(x => x.Value))
                {
                    Console.WriteLine($"{p.Key} -> {p.Value}");
                }
            }
            else
            {
                string nameType = lastCommand[0];
                foreach (var name in legioNameSoldiers)
                {
                    foreach (var value in name.Value)
                    {
                        if (value.Key == nameType)
                        {
                            if (!print.ContainsKey(name.Key))
                            {
                                print.Add(name.Key, legioNameActivity[name.Key]);
                            }
                        }
                    }
                }
                foreach (var p in print.OrderByDescending(x => x.Value))
                {
                    Console.WriteLine($"{p.Value} : {p.Key}");
                }
            }

        }
    }
}
//100pts