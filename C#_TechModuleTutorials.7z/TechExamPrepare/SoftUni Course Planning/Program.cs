﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftUni_Course_Planning
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> courses = Console.ReadLine()
                .Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries).ToList();

            string input = Console.ReadLine();
            while (input != "course start")
            {
                string[] token = input.Split(":").ToArray();
                string command = token[0];
                bool swaped = false;

                if (command == "Add")
                {
                    string lessonTitle = token[1];
                    if (!courses.Contains(lessonTitle))
                    {
                        courses.Add(lessonTitle);
                    }
                }
                else if (command == "Insert")
                {
                    string lessonTitle = token[1];
                    int index = int.Parse(token[2]);
                    if (!courses.Contains(lessonTitle) && courses.Count >= index - 1)
                    {
                        courses.Insert(index, lessonTitle);
                    }

                }
                else if (command == "Remove")
                {
                    string lessonTitle = token[1];
                    string exercice = lessonTitle + "-Exercise";
                    if (courses.Contains(lessonTitle))
                    {
                        courses.Remove(lessonTitle);
                        if (courses.Contains(exercice))
                        {
                            courses.Remove(exercice);
                        }
                    }
                }
                else if (command == "Swap")
                {
                    string lessonTitleOne = token[1];
                    string lessonTitleTwo = token[2];

                    if (courses.Contains(lessonTitleOne) && courses.Contains(lessonTitleTwo))
                    {
                        int indexOfFirst = courses.IndexOf(lessonTitleOne);
                        int indexOfSecond = courses.IndexOf(lessonTitleTwo);

                        string first = courses[indexOfFirst];
                        string second = courses[indexOfSecond];
                        string temp = courses[indexOfFirst];

                        courses.RemoveAt(indexOfFirst);                        
                        courses.Insert(indexOfFirst, second);
                        courses.RemoveAt(indexOfSecond);
                        courses.Insert(indexOfSecond, first);
                        swaped = true;
                    }

                }
                else if (command == "Exercise")
                {
                    string lessonTitle = token[1];
                    string exercice = lessonTitle + "-Exercise";

                    if (!courses.Contains(lessonTitle))
                    {
                        courses.Add(lessonTitle);
                        courses.Add(exercice);
                    }
                    else if (courses.Contains(lessonTitle) && !courses.Contains(exercice))
                    {
                        int indexOfLesson = courses.IndexOf(lessonTitle);
                        courses.Insert(indexOfLesson,exercice);
                    }

                }
                input = Console.ReadLine();
            }

            for (int i = 1; i <= courses.Count; i++)
            {
                Console.WriteLine($"{i}.{courses[i-1]}");
            }
            

        }
    }
}


//Exercice remove it  