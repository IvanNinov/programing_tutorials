﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace newLogic
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> submissions = new Dictionary<string, int>();
            Dictionary<string, int> all = new Dictionary<string, int>();



            string input = Console.ReadLine();
            while (input != "exam finished")
            {
                string[] tokens = input.Split("-", StringSplitOptions.RemoveEmptyEntries);
                if (tokens[1] != "banned")
                {
                    string username = tokens[0];
                    string language = tokens[1];
                    int points = int.Parse(tokens[2]);

                    if (!submissions.ContainsKey(username))
                    {
                        submissions.Add(username,0);
                        submissions[username] = points;
                    }
                    else
                    {
                        submissions[username] = points;
                    }

                    if (!all.ContainsKey(language))
                    {
                        all.Add(language,1);
                    }
                    else if (all.ContainsKey(language))
                    {
                        all[language]++;
                    }
                }
                else if (tokens[1] == "banned")
                {
                    string username = tokens[0];
                    if (submissions.ContainsKey(username))
                    {
                        submissions.Remove(username);
                    }
                }
                input = Console.ReadLine();
            }

            Console.WriteLine($"Results:");
            foreach (var name in submissions.OrderByDescending(x=> x.Value).ThenBy(x=>x.Key))
            {
                Console.WriteLine($"{name.Key} | { name.Value}");
            }
            Console.WriteLine($"Submissions:");
            foreach (var item in all.OrderByDescending(x=> x.Value).ThenBy(x=> x.Key))
            {
                Console.WriteLine($"{item.Key} - {item.Value}");
            }

        }
    }
}
