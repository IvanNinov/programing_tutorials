﻿using System;
using System.Collections.Generic;
using System.Text;

namespace multiply
{
    class Program
    {
        static void Main(string[] args)
        {
            string num1 = Console.ReadLine().TrimStart('0');
            string num2 = Console.ReadLine();
            int lengthBig = Math.Max(num1.Length, num2.Length);

            int sum = 0;
            int maind = 0;
            int remainder = 0;
            if (num1 == "0" || num2 == "0")
            {
                Console.WriteLine("0");
                return;
            }
            if (num1.Length < num2.Length)
            {
                string temp = num1;
                num1 = num2;
                num2 = temp;
            }



            List<int> sumOfNumbers = new List<int>();
            StringBuilder newRes = new StringBuilder();
            for (int i = num1.Length - 1; i >= 0; i--)
            {
                for (int j = num2.Length - 1; j >= 0; j--)
                {
                    sum = int.Parse(num1[i].ToString()) * int.Parse(num2[j].ToString()) + maind;
                    maind = sum / 10;
                    remainder = sum % 10;
                    sumOfNumbers.Add(remainder);
                    newRes.Insert(0, remainder.ToString());
                    if (i == 0 && maind != 0)
                    {
                        sumOfNumbers.Add(maind);
                        newRes.Insert(0,remainder.ToString());
                    }
                }
            }
            sumOfNumbers.Reverse();
            foreach (var number in sumOfNumbers)
            {
                Console.Write($"{number}");
            }
            Console.WriteLine();
            Console.WriteLine(newRes);

        }
    }
}
