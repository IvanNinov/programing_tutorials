﻿using System;
using System.Linq;
using System.Numerics;
using System.Text;

namespace onvertBase
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] tocens = Console.ReadLine().Split();       
            int @base = int.Parse(tocens[0]);
            string numAsString = tocens[1];
            BigInteger number = BigInteger.Parse(tocens[1]);
            BigInteger sum = 0;
            int pow = 0;
            for (int i = numAsString.Length - 1; i >= 0; i--)
            {
                char curChar = numAsString[i];
                int currNum = int.Parse(curChar.ToString());

                BigInteger currentSum = currNum * BigInteger.Pow(@base,pow);
                sum += currentSum;
                pow++;
            }
            Console.WriteLine(sum);

        }
    }
}
