﻿using System;

namespace charMulti
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();
            string arg1 = input[0];
            string arg2 = input[1];
            int minArr = Math.Min(arg1.Length,arg2.Length);            
            long sum = SumOfChars(arg1,arg2,minArr);
            Console.WriteLine($"{sum}");
        }

        static long SumOfChars(string str1, string str2, int min)
        {
            long sum = 0;
            string remaining = "";

            for (int i = 0; i <= min - 1 ; i++)
            {
                sum += str1[i]*str2[i];
            }
            if (str1.Length > str2.Length)
            {
                remaining = str1.Substring(min);
            }
            else
            {
                remaining = str2.Substring(min);
            }
            foreach (var chars in remaining)
            {
                sum += chars;
            }

 
            return sum;
        }
          

    }
}
