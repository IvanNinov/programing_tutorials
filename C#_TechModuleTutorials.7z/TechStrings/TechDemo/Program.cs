﻿
using System;

namespace TechDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //compare
            bool isEqual = "a" == "b";
           var equals =  String.Equals("A","B"); //sravnqva obekti ot simvoli
           var  isequals = String.Compare("A", "B", true); 
            //sravnqva obekti ot simvoli po burz                                                          
            //concat new string                                                          
            // "sdsdds" + "sdssds"                                                           
            //stringOf
            //string text = "DuraBura dva 4edura Hello";
            // int index = text.IndexOf("Hellouu");

            //string pattern = "aba";



            //Console.WriteLine($"{index}");
        }
    }
}
