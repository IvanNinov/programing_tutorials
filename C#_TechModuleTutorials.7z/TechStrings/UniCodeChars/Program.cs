﻿using System;
using System.Text;

namespace UniCodeChars
{
    class Program
    {
        static void Main(string[] args)
        {
            Encoding unicode = Encoding.Unicode;

            char[] input = Console.ReadLine().ToCharArray();
            string uni = "";

            for (int i = 0; i < input.Length; i++)
            {
                Console.Write(GetUnicodeString(input[i].ToString()));
            }
            Console.WriteLine();

        }

        static string GetUnicodeString(string s)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in s)
            {
                sb.Append("\\u");
                sb.Append($"{(int)c:x4}");
            }
            return sb.ToString();
        }
    }
}
