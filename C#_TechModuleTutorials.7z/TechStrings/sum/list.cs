﻿namespace sum
{
    internal class list<T>
    {
    }
}