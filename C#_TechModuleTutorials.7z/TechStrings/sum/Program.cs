﻿using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;


namespace sum
{
    class Program
    {
        static void Main(string[] args)
        {
            string num1 = Console.ReadLine().TrimStart('0');
            string num2 = Console.ReadLine().TrimStart('0');
            int lengthBig = Math.Max(num1.Length,num2.Length);
           // string result = num1.PadLeft(10, '0');

            int sum = 0;
            int maind = 0;
            int remainder = 0;

            if (num2.Length != num1.Length)
            {
                num1 = num1.PadLeft(lengthBig, '0');
                num2 = num2.PadLeft(lengthBig,'0');
            }
            List<int> sumOfNumbers = new List<int>();
            for (int i = lengthBig - 1; i >= 0; i--)
            {
                sum = int.Parse(num1[i].ToString()) + int.Parse(num2[i].ToString()) + maind;
                maind = sum / 10;
                remainder = sum % 10;
                sumOfNumbers.Add(remainder);
                if (i == 0 && maind != 0)
                {
                    sumOfNumbers.Add(maind);
                }
            }

            sumOfNumbers.Reverse();
            foreach (var number in sumOfNumbers)
            {
                Console.Write($"{number}");
            }
            Console.WriteLine();
        }
    }
}
